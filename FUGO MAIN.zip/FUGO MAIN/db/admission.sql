-- phpMyAdmin SQL Dump
-- version 5.2.1deb1ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 29, 2024 at 04:32 PM
-- Server version: 8.0.37-0ubuntu0.23.10.2
-- PHP Version: 8.2.10-2ubuntu2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpmyadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `_Id` int NOT NULL,
  `firstname` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `dob` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `country` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `phno` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `mail` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `address` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `city` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `state` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `school_name` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `graduation_date` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `school_city` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `school_state` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `school_country` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `register_number` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `12th_course` varchar(111) COLLATE utf8mb4_general_ci NOT NULL,
  `clg_course` varchar(111) COLLATE utf8mb4_general_ci NOT NULL,
  `clgid` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `clgfield` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`_Id`, `firstname`, `lastname`, `dob`, `gender`, `country`, `phno`, `mail`, `address`, `city`, `state`, `school_name`, `graduation_date`, `school_city`, `school_state`, `school_country`, `register_number`, `12th_course`, `clg_course`, `clgid`, `clgfield`) VALUES
(2, 'Arjun', 'C', '21-jan-2004', 'on', 'India', '7708725405', 'arjunarj@gmail.com', 'vadalur', 'Vadalur', 'TN', 'St Josephs', '2024-07-02', 'cuddalore', 'TN', 'India', '39478354', 'Computer Science', 'BCA', 'arts-01', 'arts'),
(8, 'Arjun', 'C', '21-jan-2004', 'on', 'India', '7708725405', 'arjun.chandrasekar04@gmail.com', 'vdl', 'vdl', 'tn', 'st josephs', '2019-03-03', 'cud', 'tn', 'india', '19743931294', 'Select Your 12th Course', 'BCA', 'arts-01', 'arts'),
(9, 'Arjun', 'C', '21-jan-2004', 'male', 'India', '7708725405', 'arjun.chandrasekar04@gmail.com', 'vdl', 'vdl', 'tn', 'st josephs', '2019-03-30', 'cud', 'tn', 'india', '34783249732', 'Select Your 12th Course', 'BCA', 'arts-01', 'arts'),
(10, '2', '432', '0-please select a month-Please select a year', 'male', '', '32432', '423324@gamil.co', '', '234', '324', '234', '0043-03-24', '6', '324', '324', '2234', 'Select Your 12th Course', '-1', 'arts-01', 'arts');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `_Id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
