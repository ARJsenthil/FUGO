<?php 
session_start();

session_unset();

session_destroy();

session_start();
$_SESSION['logOutSuccess'] = 'success';

header("Location: ../index.php");
?>