<?php
include 'db_conn.php';
$u_name = $_POST['u_name'];
$pass = $_POST['pass'];
session_start();
    $_SESSION['userType'] = $_GET['userType'];
    if($_SESSION['userType'] == 'student')
    {
        
        $sql = "SELECT * FROM login WHERE ( username = '$u_name' OR email = '$u_name' ) AND password = '$pass'";
        $result = $conn->query($sql);
        if ( mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_array($result);
            echo "db succes";
            $_SESSION['uname'] = $row['username'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['indexSuccess'] = 'success';
            header("Location: ../index.php?");
        } 
        else{
            header("Location: ../html/log.php?error=Invalid Username or password");
        }
    }
    else if($_SESSION['userType'] == 'admin')
    {
        // $sql = "SELECT * FROM adminlogin WHERE ( username = '$u_name' OR email = '$u_name' ) AND password = '$pass'";
        // $result = $conn->query($sql);
        if ( $u_name == 'admins' && $pass == 'admins') {
            // $row = mysqli_fetch_array($result);
            // echo "db succes";
            $_SESSION['uname'] = $u_name;
            // $_SESSION['email'] = $row['email'];
            header("Location: ../index.php?");
        } 
        else{
            header("Location: ../html/log.php?error=Invalid Username or password");
        }
    }
$conn->close();
?>