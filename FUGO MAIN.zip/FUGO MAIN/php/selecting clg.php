<?php
    session_start();
    include 'db_conn.php';
    $selectedclg = $_POST['selectedclg'];
    $selectedUniversity = -1;
    if(isset($_POST['selectedUniversity']))
    {
        $selectedUniversity = $_POST['selectedUniversity'];
    }
    echo $selectedUniversity;

    if(isset($_POST['mark']))
    {
        $mark =  $_POST['mark'];
        $grade =  $_SESSION['grade'];
    }
    if($selectedclg != -1 && $selectedUniversity != -1)
    {
        if($selectedclg == 'Medical')
        {
            if($selectedUniversity == 'Anna University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Medical Colleges From Anna University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeMedicalAnnaUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeMedicalAnnaUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeMedicalAnnaUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Medical Colleges From Anna University.';
                    header('Location: ../html/selecting clg.php?clg=medicalAnnaUniversity');
                }
            }
            else if($selectedUniversity == 'Annamalai University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Medical Colleges From Annamalai University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeMedicalAnnamalaiUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeMedicalAnnamalaiUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeMedicalAnnamalaiUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Medical Colleges From Annamalai University';                    
                    header('Location: ../html/selecting clg.php?clg=medicalAnnamalaiUniversity');
                }
            }
            else if($selectedUniversity == 'Madras University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Medical Colleges From Madras University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeMedicalMadrasUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeMedicalMadrasUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeMedicalMadrasUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Medical Colleges From Madras University';
                    header('Location: ../html/selecting clg.php?clg=medicalMadrasUniversity');
                }
            }
            else if($selectedUniversity == 'Dr. MGR University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Medical Colleges From Dr. MGR University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeMedicalDrMGRUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeMedicalDrMGRUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeMedicalDrMGRUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Medical Colleges From Dr. MGR University';
                    header('Location: ../html/selecting clg.php?clg=medicalDrMGRUniversity');
                }
            }
            else if($selectedUniversity == 'Private University')
            {
                $_SESSION['tittle'] = 'Medical Colleges From Private University';
                if(isset($_POST['mark']))
                {
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeMedicalPrivateUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeMedicalPrivateUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeMedicalPrivateUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Medical Colleges From Private University';
                    header('Location: ../html/selecting clg.php?clg=medicalPrivateUniversity');
                }
            }
        }
        else if($selectedclg == 'Engineering')
        {
            if($selectedUniversity == 'Anna University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Anna University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeEngineeringAnnaUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeEngineeringAnnaUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeEngineeringAnnaUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Anna University';
                    header('Location: ../html/selecting clg.php?clg=engineeringAnnaUniversity');
                }
            }
            else if($selectedUniversity == 'Annamalai University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Annamalai University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeEngineeringAnnamalaiUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeEngineeringAnnamalaiUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeEngineeringAnnamalaiUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Annamalai University';
                    header('Location: ../html/selecting clg.php?clg=engineeringAnnamalaiUniversity');
                }
            }
            else if($selectedUniversity == 'Madras University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Madras University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeEngineeringMadrasUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeEngineeringMadrasUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeEngineeringMadrasUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Madras University';
                    header('Location: ../html/selecting clg.php?clg=engineeringMadrasUniversity');
                }
            }
            else if($selectedUniversity == 'Dr. MGR University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Dr. MGR University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeEngineeringDrMGRUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeEngineeringDrMGRUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeEngineeringDrMGRUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Dr. MGR University';
                    header('Location: ../html/selecting clg.php?clg=engineeringDrMGRUniversity');
                }
            }
            else if($selectedUniversity == 'Private University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Private University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeEngineeringPrivateUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeEngineeringPrivateUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeEngineeringPrivateUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Engineering Colleges From Private University';
                    header('Location: ../html/selecting clg.php?clg=engineeringPrivateUniversity');
                }
            }
        }
        else if($selectedclg == 'Arts & Science')
        {
            if($selectedUniversity == 'Anna University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Anna University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeArtsAnnaUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeArtsAnnaUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeArtsAnnaUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Anna University';
                    header('Location: ../html/selecting clg.php?clg=artsAnnaUniversity');
                }
            }
            else if($selectedUniversity == 'Annamalai University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Annamalai University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeArtsAnnamalaiUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeArtsAnnamalaiUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeArtsAnnamalaiUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Annamalai University';
                    header('Location: ../html/selecting clg.php?clg=artsAnnamalaiUniversity');
                }
            }
            else if($selectedUniversity == 'Madras University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Madras University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeArtsMadrasUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeArtsMadrasUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeArtsMadrasUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Madras University';
                    header('Location: ../html/selecting clg.php?clg=artsMadrasUniversity');
                }
            }
            else if($selectedUniversity == 'Dr. MGR University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Dr. MGR University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeArtsDrMGRUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeArtsDrMGRUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeArtsDrMGRUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Dr. MGR University';
                    header('Location: ../html/selecting clg.php?clg=artsDrMGRUniversity');
                }
            }
            else if($selectedUniversity == 'Private University')
            {
                if(isset($_POST['mark']))
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Private University For You';
                    if($grade == 'a')
                    {
                        header('Location: ../html/selecting clg.php?clg=allAGradeArtsPrivateUniversity');
                    }
                    else if($grade == 'b')
                    {
                        header('Location: ../html/selecting clg.php?clg=allBGradeArtsPrivateUniversity');
                    }
                    else if($grade == 'c')
                    {
                        header('Location: ../html/selecting clg.php?clg=allCGradeArtsPrivateUniversity');
                    }
                }
                else
                {
                    $_SESSION['tittle'] = 'Arts & Science Colleges From Private University ';
                    header('Location: ../html/selecting clg.php?clg=artsPrivateUniversity');
                }
            }
        }
        
    }
    else if($selectedclg != -1 && $selectedUniversity == -1)
    {
        echo $selectedclg;
        if($selectedclg == 'Medical')
        {
            $_SESSION['tittle'] = 'Medical Colleges For You';
            if(isset($_POST['mark']))
            {
                if($grade == 'a')
                {
                    header('Location: ../html/selecting clg.php?clg=allMedicalClg');
                }
                else if($grade == 'b')
                {
                    header('Location: ../html/selecting clg.php?clg=allBGradeMedicalClg');
                }
                else if($grade == 'c')
                {
                    header('Location: ../html/selecting clg.php?clg=allCGradeMedicalClg');
                }
            }
            else
            {
                $_SESSION['tittle'] = 'Medical Colleges';
                header('Location: ../html/selecting clg.php?clg=allMedicalClg');
            }
        }
        else if($selectedclg == 'Engineering')
        {

            if(isset($_POST['mark']))
            {
                $_SESSION['tittle'] = 'Engineering Colleges For You';
                if($grade == 'a')
                {
                    header('Location: ../html/selecting clg.php?clg=allEngineeringClg');
                }
                else if($grade == 'b')
                {
                    header('Location: ../html/selecting clg.php?clg=allBGradeEngineeringClg');
                }
                else if($grade == 'c')
                {
                    header('Location: ../html/selecting clg.php?clg=allCGradeEngineeringClg');
                }
            }
            else
            {
                $_SESSION['tittle'] = 'Engineering Colleges';
                header('Location: ../html/selecting clg.php?clg=allEngineeringClg');
            }
        }
        else if($selectedclg == 'Arts & Science')
        {
            if(isset($_POST['mark']))
            {
                $_SESSION['tittle'] = 'Arts & Science Colleges For You';
                if($grade == 'a')
                {
                    header('Location: ../html/selecting clg.php?clg=allArtsClg');
                }
                else if($grade == 'b')
                {
                    header('Location: ../html/selecting clg.php?clg=allBGradeArtsClg');
                }
                else if($grade == 'c')
                {
                    header('Location: ../html/selecting clg.php?clg=allCGradeArtsClg');
                }
            }
            else
            {
                $_SESSION['tittle'] = 'Arts & Science Colleges';
                header('Location: ../html/selecting clg.php?clg=allArtsClg');
            }
        }
        else if($selectedclg == 'Diploma')
        {
            if(isset($_POST['mark']))
            {
                $_SESSION['tittle'] = 'Diploma For You';
                if($grade == 'a')
                {
                    header('Location: ../html/selecting clg.php?clg=allDiplomaClg');
                }
                else if($grade == 'b')
                {
                    header('Location: ../html/selecting clg.php?clg=allBGradeDiplomaClg');
                }
                else if($grade == 'c')
                {
                    header('Location: ../html/selecting clg.php?clg=allCGradeDiplomaClg');
                }
            }
            else
            {
                $_SESSION['tittle'] = 'Diploma Colleges';
                header('Location: ../html/selecting clg.php?clg=allDiplomaClg');
            }
        }
    }
    else if($selectedclg == -1 && $selectedUniversity != -1)
    {
        echo 'hi';
        if($selectedUniversity == 'Anna University')
        {
            $_SESSION['tittle'] = 'Anna University Affiliated Colleges For You';
            if(isset($_POST['mark']))
            {
                if($grade == 'a')
                {
                    header('Location: ../html/selecting clg.php?clg=allAGradeAnnaUniversityClg');
                }
                else if($grade == 'b')
                {
                    header('Location: ../html/selecting clg.php?clg=allBGradeAnnaUniversityClg');
                }
                else if($grade == 'c')
                {
                    header('Location: ../html/selecting clg.php?clg=allCGradeAnnaUniversityClg');
                }
            }
            else
            {
                $_SESSION['tittle'] = 'Anna University Affiliated Colleges';
                header('Location: ../html/selecting clg.php?clg=allAnnaUniversityClg');
            }
        }
        else if($selectedUniversity == 'Annamalai University')
        {
            if(isset($_POST['mark']))
            {
                $_SESSION['tittle'] = 'Annamalai University Affiliated Colleges For You';
                if($grade == 'a')
                {
                    header('Location: ../html/selecting clg.php?clg=allAGradeAnnamalaiUniversityClg');
                }
                else if($grade == 'b')
                {
                    header('Location: ../html/selecting clg.php?clg=allBGradeAnnamalaiUniversityClg');
                }
                else if($grade == 'c')
                {
                    header('Location: ../html/selecting clg.php?clg=allCGradeAnnamalaiUniversityClg');
                }
            }
            else
            {
                $_SESSION['tittle'] = 'Annamalai University Affiliated Colleges';
                header('Location: ../html/selecting clg.php?clg=allAnnamalaiUniversityClg');
            }
        }
        else if($selectedUniversity == 'Madras University')
        {
            if(isset($_POST['mark']))
            {
                $_SESSION['tittle'] = 'Madras University Affiliated Colleges For You';
                if($grade == 'a')
                {
                    header('Location: ../html/selecting clg.php?clg=allAGradeMadrasUniversityClg');
                }
                else if($grade == 'b')
                {
                    header('Location: ../html/selecting clg.php?clg=allBGradeMadrasUniversityClg');
                }
                else if($grade == 'c')
                {
                    header('Location: ../html/selecting clg.php?clg=allCGradeMadrasUniversityClg');
                }
            }
            else
            {
                $_SESSION['tittle'] = 'Madras University Affiliated Colleges';
                header('Location: ../html/selecting clg.php?clg=allMadrasUniversityClg');
            }
        }
        else if($selectedUniversity == 'Dr. MGR University')
        {
            if(isset($_POST['mark']))
            {
                $_SESSION['tittle'] = 'Dr. MGR University Affiliated Colleges For You';
                if($grade == 'a')
                {
                    header('Location: ../html/selecting clg.php?clg=allAGradeDrMGRUniversityClg');
                }
                else if($grade == 'b')
                {
                    header('Location: ../html/selecting clg.php?clg=allBGradeDrMGRUniversityClg');
                }
                else if($grade == 'c')
                {
                    header('Location: ../html/selecting clg.php?clg=allCGradeDrMGRUniversityClg');
                }
            }
            else
            {
                $_SESSION['tittle'] = 'Dr. MGR University Affiliated Colleges';
                header('Location: ../html/selecting clg.php?clg=allDrMGRUniversityClg');
            }
        }
        else if($selectedUniversity == 'Private University')
        {
            if(isset($_POST['mark']))
            {
                $_SESSION['tittle'] = 'Private University Affiliated Colleges For You';
                if($grade == 'a')
                {
                    header('Location: ../html/selecting clg.php?clg=allAGradePrivateUniversityClg');
                }
                else if($grade == 'b')
                {
                    header('Location: ../html/selecting clg.php?clg=allBGradePrivateUniversityClg');
                }
                else if($grade == 'c')
                {
                    header('Location: ../html/selecting clg.php?clg=allCGradePrivateUniversityClg');
                }
            }
            else
            {
                $_SESSION['tittle'] = 'Private University Affiliated Colleges';
                header('Location: ../html/selecting clg.php?clg=allPrivateUniversityClg');
            }
        }
    }
    else
    {
        if(isset($_POST['mark']))
        {
            $_SESSION['tittle'] = 'Colleges For You';
            if($grade == 'a')
            {
                header('Location: ../html/selecting clg.php?clg=allAGradeClg');
            }
            else if($grade == 'b')
            {
                header('Location: ../html/selecting clg.php?clg=allBGradeClg');
            }
            else if($grade == 'c')
            {
                header('Location: ../html/selecting clg.php?clg=allCGradeClg');
            }
        }
        else
        {
            $_SESSION['tittle'] = 'Colleges';
            header('Location: ../html/selecting clg.php?clg=allClg');
        }
    }
    
?>