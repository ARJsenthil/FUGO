<?php
session_start();
$requestUrl = $_SERVER['REQUEST_URI'];
$arr = explode('?',$requestUrl);
$data = explode("-",$arr[1]);
include "./db_conn.php";
$id = $data[0];
$type = $data[1];
$tableName = $data[2];
echo $id."-".$type;
$deleteQuery = "delete from $tableName where _Id = $id";
$sql = $conn->query($deleteQuery);
if($sql) {
    $_SESSION['deleteStatus'] = 200;
    $_SESSION['deletedDataId'] = $id;
    header("Location: ../html/admin.php?menu=$type");
}
else if(!$sql) {
    $_SESSION['deleteStatus'] = 400;
    header("Location: ../html/admin.php?menu=$type");
}

?>