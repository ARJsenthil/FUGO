<?php 
    include 'db_conn.php';

    $clgid = $_POST['clgid'];
    $clgname = $_POST['clgname'];
    $clgdet = $_POST['clgdet'];
    $clgimgsrc = $_POST['clgimgsrc'];
    $clgtype = $_POST['clgtype'];
    $clgestablished = $_POST['clgestablished'];
    $clgprinciple = $_POST['clgprinciple'];
    $clglocation = $_POST['clglocation'];
    $clgcampus = $_POST['clgcampus'];
    $clgaffiliattions = $_POST['clgaffiliattions'];
    $clgwebsite = $_POST['clgwebsite'];
    $clgfield = $_POST['clgfield'];

    echo $clgid. $clgname. $clgdet. $clgimgsrc. $clgtype. $clgestablished. $clgprinciple. $clglocation. $clgcampus. $clgaffiliattions. $clgwebsite. $clgfield;


    $sql = "insert into clgdet(clgid, clgname, clgdet, clgimgsrc, clgtype, clgestablished, clgprinciple, clglocation, clgcampus, clgaffiliattions, clgwebsite, clgfield) values('$clgid', '$clgname', '$clgdet', '$clgimgsrc', '$clgtype', '$clgestablished', '$clgprinciple', '$clglocation', '$clgcampus', '$clgaffiliattions', '$clgwebsite', '$clgfield')";
    // $conn->query($sql);
    if ($conn->query($sql)) {
        echo "Inserted";
        header("Location: insert table.php");
    }
    else
    {
        echo "Not Inserted";

    }

?>