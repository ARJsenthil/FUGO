<?php
include 'db_conn.php';
session_start();
$_SESSION['error_remover'] = 1;
$f_name = $_POST['f_name'];
$email = $_POST['email'];
$u_name = $_POST['u_name'];
$pass = $_POST['pass'];
$sql = "insert into login (fullname, username, password, email) values('$f_name', '$u_name', '$pass', '$email')";
try {
    // Attempt to execute the query
    if($conn->query($sql)) {
        echo "Inserted";
            $_SESSION['regSuccess'] = 'success';
            echo $_SESSION['regSuccess'];
            header("Location: ../html/log.php");

    } else {
        echo "Error: " . $mysqli->error;
    }
} catch (mysqli_sql_exception $e) {
    // Check for duplicate entry error
    if($e->getCode()) {
        echo 'hi';
        $errorMessage = $e->getMessage();
        if(strpos($errorMessage, 'username') !== false) {
            header("Location: ../html/register.php?error= Username already exists. Please choose a different username.");
            echo "Error: Username already exists. Please choose a different username.";
        } else if(strpos($errorMessage, 'email') !== false) {
            header("Location: ../html/register.php?error= Email already exists. Please choose a different email.");
            echo "Error: Email already exists. Please choose a different email.";
        } else {
            header("Location: ../html/register.php?error=Duplicate entry error");
            echo "Error: Duplicate entry error.";
        }
    }
}
$conn->close();
?>