<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css">
    <title>Document</title>
    <style>
        input{
            height: 45px;
            padding: 10px;
        }
    </style>
</head>
<body>
<a href="../html/admin.php?menu=clg" class="" style="text-align: center;">Back</a>
    <form action="insert.php" style="display: grid; gap: 10px;" method="post">
    <input type="text" required name="clgid" placeholder="clgid"/>
    <input type="text" required name="clgname" placeholder="clgname"/>
    <input type="text" required name="clgdet" placeholder="clgdet"/>
    <input type="text" required name="clgimgsrc" placeholder="clgimgsrc"/>
    <input type="text" required name="clgtype" placeholder="clgtype"/>
    <input type="text" required name="clgestablished" placeholder="clgestablished"/>
    <input type="text" required name="clgprinciple" placeholder="clgprinciple"/>
    <input type="text" required name="clglocation" placeholder="clglocation"/>
    <input type="text" required name="clgcampus" placeholder="clgcampus"/>
    <input type="text" required name="clgaffiliattions" placeholder="clgaffiliattions"/>
    <input type="text" required name="clgwebsite" placeholder="clgwebsite"/>
    <input type="text" required name="clgfield" placeholder="clgfield"/>
    <input type="submit" value="Submit" style="height: 45px;">
    <a href="../html/admin.php?menu=clg" class="" style="text-align: center;">Back</a>
    </form>
</body>
</html>






