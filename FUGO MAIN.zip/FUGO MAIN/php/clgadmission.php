<?php 
session_start();
include 'db_conn.php';

    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $dob = $_POST['date'].'-'.$_POST['month'].'-'.$_POST['year'];
    $gender = $_POST['gender'];
    $country = $_POST['country'];
    $phno = $_POST['phone'];
    $mail = $_POST['email'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $school_name = $_POST['school_name'];
    $graduation_date = $_POST['graduation_date'];
    // $school_address = $_POST['school_address'];
    $school_city = $_POST['school_city'];
    $school_state = $_POST['school_state'];
    $school_country = $_POST['school_country'];
    $register_number = $_POST['register_number'];
    $school_12th_course = $_POST['12th_course'];
    $clg_course = $_POST['degree'];
    $clg_id = $_GET['clgid'];
    $clg_field = $_GET['clgfield'];

    // echo $clgid. $clgname. $clgdet. $clgimgsrc. $clgtype. $clgestablished. $clgprinciple. $clglocation. $clgcampus. $clgaffiliattions. $clgwebsite. $clgfield. $clggrade;

    $sql = "insert into admission (firstname, lastname, dob, gender, country, phno, mail, address, city, state, school_name, graduation_date, school_city, school_state, school_country, register_number, 12th_course, clg_course, clgid, clgfield) values ('$firstname', '$lastname', '$dob', '$gender', '$country', '$phno', '$mail', '$address', '$city', '$state', '$school_name', '$graduation_date', '$school_city', '$school_state', '$school_country', '$register_number', '$school_12th_course', '$clg_course', '$clg_id', '$clg_field')";
    // $conn->query($sql);
    if ($conn->query($sql)) {
        echo "Inserted";
        $_SESSION['admissionSucces'] = 'success';
        header('Location: ../html/selecting clg.php');
    }
    else
    {
        echo "Not Inserted";

    }


?>