<?php
include 'db_conn.php';
session_start();
$uname = $_SESSION['uname'];
$per = $_POST['per_span'];
echo $per.$uname;
$_SESSION['temp'] = 1;
$group = $_POST['group'];
if($per != 0 && $per != '---')
{
        if($per >= 35 && $per <= 100)
        {
        echo 'good'.$per;
        if($per >= 80 && $per <=100)
        {   
            $_SESSION['tittle'] = 'All Colleges For You';
            $perGrade = 'a';
            echo $perGrade;
            $sql = "update login set mark = '$per', grade = '$perGrade', 12th_course = '$group' where username = '$uname' or email = '$uname'";
            $conn->query($sql);
                echo "Inserted";
                header("Location: ../html/selecting clg.php?clg=allAGradeClg");

        }
        else if($per >= 60 && $per <= 79)
        {
            $_SESSION['tittle'] = 'All Colleges For You';
            $perGrade = 'b';
            echo $perGrade;
            $sql = "update login set mark = '$per', grade = '$perGrade', 12th_course = '$group' where username = '$uname' or email = '$uname'";
            $conn->query($sql);
                echo "Inserted";
                header("Location: ../html/selecting clg.php?clg=allBGradeClg");

        }
        else
        {
        echo 'good';

            $_SESSION['tittle'] = 'All Colleges For You';
            $perGrade = 'c';
            echo $perGrade;
            $sql = "update login set mark = '$per', grade = '$perGrade', 12th_course = '$group' where username = '$uname' or email = '$uname'";
            $conn->query($sql);
                echo "Inserted";
                header("Location: ../html/selecting clg.php?clg=allCGradeClg");

        }
        // if($perGrade)
        // {
        //     echo $perGrade;
        //     $sql = "update login set mark = '$per', grade = '$perGrade' where username = '$uname' or email = '$uname'";
        //     $conn->query($sql);
        //         echo "Inserted";
        //         header("Location: ../html/selecting clg.php?");
        // }
        
    }

    } else {
        header("Location: ../html/for you.php?error=Complete Your Calculation");
    }
$conn->close();
?>