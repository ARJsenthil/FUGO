
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
</head>
<body>
    <footer>
        <section class="foot">
          <div class="fst">
              <img src="" alt="logo"/>
              <h3>FUGO!</h3>
          </div>
          <div class="snd">
              <p class="bold">CONTACT:</p>
              <p class="norm"><span><i class="fa-solid fa-phone"></i></span> +91 123 123 1234</p>
              <p class="norm"><span><i class="fa-solid fa-envelope"></i></span> fugo@gmail.com</p>
              <p class="bold">FOR ADMISSION:</p>
              <p class="norm"><span><i class="fa-solid fa-phone"></i></span> +91 123 123 1234</p>
              <p class="norm"><span><i class="fa-solid fa-envelope"></i></span> admission@gmail.com</p>
          </div>
          <div class="trd">
              <p class="bold">COMMON QUESTIONS:</p>
              <a href="#"><p class="norm">Popular colleges</p></a>
              <a href="#"><p class="norm">Locations</p></a>
              <a href="#"><p class="norm">Engineering colleges</p></a>
              <a href="#"><p class="norm">Arts and science colleges</p></a> 
              <a href="#"><p class="norm">Medical colleges</p></a>   
          </div>
          <div class="fth">
              <p class="bold">QUICK LINKS:</p>
              <a href="../index.php" target=""><p class="norm">Home</p></a>
              <a href="selecting clg.php" target=""><p class="norm">Colleges</p></a>
              <a href="about.html" target=""><p class="norm">About us</p></a>
              <a href="contact.php" target=""><p class="norm">Contacts</p></a>
              <a href="log.php" target="" id="footerprofile"><p class="norm" id="footerprofileP">Login</p></a>
          <div class="ft-icons"></div>
              <a href="#"><span><i class="icons fa-brands fa-instagram"></i></span></a> 
              <a href="#"><span><i class="icons fa-brands fa-square-x-twitter"></i></span></a>
              <a href="#"><span><i class="icons fa-brands fa-facebook"></i></span></a>
              <a href="#"><span><i class="icons fa-brands fa-whatsapp"></i></span></a>
              <a href="#"><span><i class="icons fa-solid fa-envelope"></i></span></a>
          </div>
          </div>
      </section>
      <section class="extra">
          <p class="ext"><span><i class="fa-solid fa-copyright"></i></span> Copyrights FUGO! portal 2024. All rights reserved by the developers.</p>
      </section>
    </footer>
</body>
<script>
  const footerprofile = document.getElementById('footerprofile');
  const footerprofileP = document.getElementById('footerprofileP');
    if(userType.value == 'student' || userType.value == 'admin')
    <?php
        if(isset($_SESSION['userType']))
      {
    echo "{
      footerprofileP.innerHTML = 'Profile'
      footerprofile.href = '#'
    }
    localStorage.setItem('userType', userType.value);
    localStorage.setItem('uname', userName.value);";
}
?>
</script>
</html>