<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIGN UP</title>
    <link rel="stylesheet" href="../css/log.css" />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css" />
    <script src="../js/reg.js"></script>    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        footer
        {
            margin-top: 800px;
        }
    </style>
</head>
<body onload="onclickStudent()">
<div class="main row m-auto">
        <div class="left-cont col-12 col-lg-5">
            <img src="../media/images/log_img.webp" alt="book"/>
            <h1>Welcome To <b>FUGO!</b></h1>

        </div>
        <div class="right-cont col-12 col-lg-7">
            <div class="top-cont">
                <a class="obj rounded" href="#" id="student" onclick="onclickStudent()">Students</a>
                <a class="obj rounded"href="#" id="admin" onclick="onclickAdmin()">Admin</a>
            </div>
            <form id="form" class="" action="../php/reg.php" method="POST">
                <div class="log-logo-box">
                <h1>Sign Up</h1>
                </div>
            
            <div class="user-div">
                <input type="text" name="f_name" placeholder="Full Name" class="w-100 rounded shadow-sm" id="f_name" minlength="6" maxlength="15" required/>
            </div>

            <div class="user-div">
                <input type="email" name="email" placeholder="Email" class="w-100 rounded shadow-sm" id="email" minlength="6" maxlength="25" required/>
            </div>

            <div class="user-div">
                <input type="text" name="u_name" placeholder="Username" class="w-100 rounded shadow-sm" id="u_name" minlength="6" maxlength="15" required/>
            </div>


            <div class="pass-div">
                <input type="password" name="pass" placeholder="password" class="w-100 rounded shadow-sm" id="pass" minlength="6" maxlength="10" required/> 
                <i class="fa-solid fa-eye open-eye" id="open-eye" onclick="pass()"></i> <i style="display:none" class= "fa-solid fa-eye-slash close-eye" id="close-eye" onclick="pass()"></i>
            </div>

           
           <div class="continue-btn">
            <!-- <a  class="" href="#">Continue</a> -->
            <input type="submit" class="d-inline-block w-100 text-center py-2 rounded" value="Continue">
           </div>

           <div class="register-btn">
            <a  class="d-inline-block w-100 text-center" href="log.php">Login</a>
           </div>

           <div class="">
            <!-- <?php  ?> -->

                <p class="error text-danger font-weight-bold text-center"><?php if (isset($_GET['error'])) { echo $_GET['error']; }?></p>
    
            <!-- <?php  ?> -->
           </div>
            </form>
            <div class=" position-absolute" id="reg_admin" style="top: 50%; left: 50%; !important; transform: translate(-50%, -50%);">
                <p>Contact fugo to get an admin registration</p>
            </div>

        </div>
    </div>

   
        
   <footer>
    <section class="foot">
      <div class="fst">
          <img src="" alt="logo"/>
          <h3>FUGO!</h3>
      </div>
      <div class="snd">
          <p class="bold">CONTACT:</p>
          <p class="norm"><span><i class="fa-solid fa-phone"></i></span> +91 91 50 602 650</p>
          <p class="norm"><span><i class="fa-solid fa-envelope"></i></span> abineshdio23@gmail.com</p>
          <p class="bold">FOR ADMISSION:</p>
          <p class="norm"><span><i class="fa-solid fa-phone"></i></span> +91 87 57 456 897</p>
          <p class="norm"><span><i class="fa-solid fa-envelope"></i></span> admission@gmail.com</p>
      </div>
      <div class="trd">
          <p class="bold">COMMON QUESTIONS:</p>
          <a href="#"><p class="norm">Popular colleges</p></a>
          <a href="#"><p class="norm">Locations</p></a>
          <a href="#"><p class="norm">Engineering colleges</p></a>
          <a href="#"><p class="norm">Arts and science colleges</p></a> 
          <a href="#"><p class="norm">Medical colleges</p></a>   
       </div>
      <div class="fth">
          <p class="bold">QUICK LINKS:</p>
          <a href="../index.php" target=""><p class="norm">Home</p></a>
          <a href="./selecting clg.php" target=""><p class="norm">Colleges</p></a>
          <a href="#" target=""><p class="norm">About us</p></a>
          <a href="./contact.php" target=""><p class="norm">Contacts</p></a>
          <a href="./log.php" target=""><p class="norm">Profile</p></a>
      <div class="ft-icons"></div>
          <a href="#"><span><i class="icons fa-brands fa-instagram"></i></span></a> 
          <a href="#"><span><i class="icons fa-brands fa-square-x-twitter"></i></span></a>
          <a href="#"><span><i class="icons fa-brands fa-facebook"></i></span></a>
          <a href="#"><span><i class="icons fa-brands fa-whatsapp"></i></span></a>
          <a href="#"><span><i class="icons fa-solid fa-envelope"></i></span></a>
      </div>
      </div>
  </section>
  <section class="extra">
      <p class="ext"><span><i class="fa-solid fa-copyright"></i></span> Copyrights FUGO! portal 2024. All rights reserved by the developers.</p>
  </section>
  </footer>
</body>
<script>
    
    const student = document.getElementById('student')
    const admin = document.getElementById('admin')
    const form = document.getElementById('form')
    const reg_admin = document.getElementById('reg_admin')
    var userType = '';
    function onclickAdmin()
    {
        userType = 'admin';
        admin.classList.add('userType');
        form.classList.add('d-none');
        student.classList.remove('userType');
        reg_admin.classList.remove('d-none');
    }
    function onclickStudent()
    {
        userType = 'student';
        student.classList.add('userType');        
        reg_admin.classList.add('d-none');
        admin.classList.remove('userType');  
        form.classList.remove('d-none');
    }
</script>
</html>