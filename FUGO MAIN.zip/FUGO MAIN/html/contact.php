<?php session_start();?>
<html>
<head>
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        
        .contact
        {
            padding: 20px 0px;
        }
        .contact-top-container
        {
            
        }
        .contact-top-container h1
        {
            margin: 0%;
            color: rgba(9, 190, 250, 0.9);
            font-size: xx-large;
            font-weight: 900;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        .contact-top-container p:last-child
        {
            font-size: 18px;
            opacity: .9;
        }
        .contact-bottom-container
        {
        }
        .contact .contact-main-container
        {
            height: 590px;
            border-top: 3px solid #47b2e4;
            border-bottom: 3px solid #47b2e4;
            box-shadow: 1px 1px 5px 5px rgba(0, 0, 0, 0.03);
            padding: 25px;
        }
        .contact-main-container textarea
        {
            min-height: 226.3px;
            max-height: 226.3px;
        }
        .contact .contact-main-container svg
        {
            color: #47b2e4;
        }
        .contact .contact-main-container .icon
        {
            /* padding: 9px 13px 11px 13px; */
            padding: 13px;
            background-color: #47b2e444;
        }
        .contact .contact-main-container .icon-box
        {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .contact .contact-main-container
        {
            h1
            {
                font-size: large;
            }
            p
            {
                font-size: medium;
            }
        }

        @media screen and (max-width: 991px) {
            .home-content
            {
                text-align: center !important;
                order: 2 !important;

                h1
                {
                    font-size: xxx-large !important;
                }
                p
                {
                    font-size: large !important;
                }
                .home-watch-box
                {
                    justify-content: center !important;
                    margin: 10px 0px 30px 0px!important;
                }
            }
            .home-img-box
            {
                order: 1 !important;
            }

            .about .about-right-content
            {
                padding-top: 15px;
            }
            .why-us .why-us-right-container
            {
                padding-top: 30px;
            }
            .contact .c-b-1
            {
                border-bottom: none !important;
            }
            .contact .c-b-2
            {
                border-top: none !important;
            }
        }

        @media screen and (max-width: 480px){
            .home-content
            {
            }
                h1
                {
                    font-size: xx-large !important;
                p
                {
                    font-size: medium !important;
                }
                .home-watch-box
            {
            }
                margin: 10px 0px !important;
            }
            .contact
            {
                .contact-top-container
                {
                    p
                    {
                    font-size: medium !important;
                    }
                    h1
                    {
                        font-size: 27px !important;
                    }
                }

            }
        }
    </style>
</head>
    <body>
    <?php include 'header.php';?>
        <section class="contact" id="contact">
            <div class="container">
              <div class="contact-top-container text-center">
                <h1 class="">CONTACT</h1>
                <p class="py-3">Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
              </div>
              <div class="contact-bottom-container row">
                <div class="contact-bl-container col-lg-5 col-12">
                  <div class="contact-main-container c-b-1">
                    <div class="box row my-1 justify-content-center align-items-center">
                      <div class="icon-box col-2">
                      <div class="icon  d-inline-block rounded-circle">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-geo-alt" viewBox="0 0 16 16">
                          <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A32 32 0 0 1 8 14.58a32 32 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10"/>
                          <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4m0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
                        </svg>
                      </div>
                      </div>
                      <div class="txt col-10">
                        <h1 class="my-1">Location:</h1>
                        <p class="my-1">A108 Adam Street, New York, NY 535022</p>
                      </div>
                    </div>
                    <div class="box row my-1 justify-content-center align-items-center">
                      <div class="icon-box col-2">
                      <div class="icon d-inline-block rounded-circle">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
                          <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z"/>
                        </svg>
                      </div>
                      </div>
                      <div class="txt col-10">
                        <h1 class="my-1">Email:</h1>
                        <p class="my-1">info@example.com</p>
                      </div>
                    </div>
                    <div class="box row my-1 mb-2 justify-content-center align-items-center">
                      <div class="icon-box col-2">
                      <div class="icon d-inline-block rounded-circle">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-phone" viewBox="0 0 16 16">
                          <path d="M11 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM5 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z"/>
                          <path d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2"/>
                        </svg>
                      </div>
                      </div>
                      <div class="txt col-10">
                        <h1 class="my-1">Call:</h1>
                        <p class="my-1">+1 5589 55488 55s</p>
                      </div>
                    </div>
                    <div class="map">
                      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d997640.0011493795!2d79.28539197645424!3d12.380838653939573!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5498f22ccc2157%3A0x962571751d010b9e!2sSt.%20Josephs%20College%20of%20Arts%20and%20Science!5e0!3m2!1sen!2sin!4v1710306224001!5m2!1sen!2sin" width="300" class="mt-2 w-100" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                  </div>
                </div>
                <div class="contact-br-container col-lg-7 col-12">
                  <div class="contact-main-container c-b-2">
                    <form>
                      <div class="form-row">
                        <div class="form-group col-md-6">
                          <label for="name">Your Name</label>
                          <input type="text" class="form-control" name="name">
                        </div>
                        <div class="form-group col-md-6">
                          <label for="email">Your Email</label>
                          <input type="text" class="form-control" name="email">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" class="form-control" name="subject">
                      </div>
                      <div class="form-group">
                        <label for="message">Message</label>
                        <textarea class="form-control"></textarea>
        
                      </div>
                      
                      <button type="submit" class="btn btn-primary d-block m-auto">Submit Message</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </section>
      <?php include 'footer.php';?>
</body>
<script>
  const clgMenu = document.getElementById('contact');
  clgMenu.classList.add('glow');
</script>
</html>