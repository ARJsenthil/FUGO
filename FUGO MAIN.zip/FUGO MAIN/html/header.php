<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap-icons.css">
    <title>Document</title>
</head>
<body>
  <?php
    // session_start();
    if(isset($_SESSION['userType']))
    {
    echo '<input id="userType" style="display: none; type="text" value='.$_SESSION['userType'].' />';
    echo '<input id="userName" style="display: none; type="text" value='.$_SESSION['uname'].' />';
    }
?>
    <header class="header ">
        
        <nav class="navbar navbar-expand-lg navbar-light c-w m-auto">
            <a class="navbar-brand h-1" href="#">FUGO!</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav m-auto">
                <li class="menu">
                  <a class="nav-link" href="../index.php">Home</a>
                </li>
                <li class="  menu" id="selectingClg">
                  <a class="nav-link" href="selecting clg.php">Colleges</a>
                </li>
                <li class="  menu" id="about">
                    <a class="nav-link" href="about.php">About us</a>
                  </li>
                  
                  <?php 
                  if(isset($_SESSION['userType']))
                  {
                    if($_SESSION['userType'] != 'admin')
                    {
                      echo '<li class="  menu" id="contact">
                      <a class="nav-link" href="contact.php">Contacts</a>
                    </li>';
                    }
                  }
                  else{
                    echo '<li class="  menu" id="contact">
                      <a class="nav-link" href="contact.php">Contacts</a>
                    </li>';
                  }
                  ?>

                  <?php 
                  if(isset($_SESSION['userType']))
                    if($_SESSION['userType'] == 'admin')
                    {
                      echo '<li class="  menu" id="contact">
                      <a class="nav-link" href="admin.php?menu=dBoard">Admin Panel</a>
                    </li>';
                    }
                  ?>
                  <li class="  menu" id="log">
                    <a class="nav-link" href="log.php" id="profile">Login</a>
                  </li>
              </ul>
              <div class="box-1" id="">
                  <a href="log.php" class="button-1" id="forYou">For You</a>
              </div>
              
            </div>
          </nav>
    </header>
</body>
<script>
  const forYou = document.getElementById('forYou');
  const profile = document.getElementById('profile');
  const userType = document.getElementById('userType');
  const userName = document.getElementById('userName');
  <?php
  if(isset($_SESSION['userType']))
  {
  echo "
  console.log('123')
    if(userType.value == 'student' || userType.value == 'admin')
    {
      console.log('123')
      forYou.href = 'for you.php';
      profile.innerHTML = 'Logout'
      profile.href = '../php/log out.php'
    }
    localStorage.setItem('userType', userType.value);
    localStorage.setItem('uname', userName.value);
  ";}?>
</script>
</html>