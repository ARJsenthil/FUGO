<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
    <?php include 'header.php'?>
    <div class="admin-main d-flex"style="height: 100%;">
        <div class="admin-menu border-right  " style="height: 100vh; width: 23%;">
            <h3 class="text-center p-3 pt-4">Admin Panel</h3>
            <ul class="nav w-100" style="display: grid;">
                <a id="dBoard" class="d-board w-100 py-3 pl-5 border-top text-dark d-inline-block" href="admin.php?menu=dBoard">Dashboard</a>
                <a id="users" class="users w-100 py-3 pl-5 border-top text-dark d-inline-block" href="admin.php?menu=user">Users</a>
                <a id="colleges" class="colleges w-100 py-3 pl-5 border-top text-dark d-inline-block" href="admin.php?menu=clg">Colleges</a>
                <a id="Admissions" class="Admissions w-100 py-3 pl-5 border-top border-bottom text-dark d-inline-block" href="admin.php?menu=admission">Admissions</a>
            </ul>
        </div>
        <div class="admin-contant " style="height: 100vh; width: 77%;">
    <?php
    include '../php/db_conn.php';
    function dBoard($conn)
    {
    $select = 'select * from login';
        $selectQuery = $conn->query($select);
      $userCount = 0;
        while($row = mysqli_fetch_array($selectQuery))
        {
          $userCount++;
        }   
        echo '</tbody>
        </table>';
        
        $select = 'select * from clgdet';
        $selectQuery = $conn->query($select);
        $clgCount = 0;
        while($row = mysqli_fetch_array($selectQuery))
        {
          $clgCount ++;
        }   

        $select = 'select * from admission';
        $selectQuery = $conn->query($select);
        $admissionCount = 0;
        while($row = mysqli_fetch_array($selectQuery))
        {
          $admissionCount ++;
        }   
        echo '<div class="container row m-auto"><div class="col-4 bg-warning p-5 border-right"><a class="d-flex justify-content-center align-items-center font-weight-bold" href="admin.php?menu=user"><span>No. Of Users</span> <span class="ml-2  mb-1" style="font-size: 25px;">'.$userCount.'</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-people-fill mb-1 ml-3" viewBox="0 0 16 16">
        <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5"/>
        </svg>
        </a></div><div class="col-4 bg-warning p-5 border-right"><a class="d-flex justify-content-center align-items-center font-weight-bold" href="admin.php?menu=clg"><span>No. Of Colleges</span> <span class="ml-2  mb-1" style="font-size: 25px;">'.$clgCount.'</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-mortarboard-fill mb-1 ml-3" viewBox="0 0 16 16">
        <path d="M8.211 2.047a.5.5 0 0 0-.422 0l-7.5 3.5a.5.5 0 0 0 .025.917l7.5 3a.5.5 0 0 0 .372 0L14 7.14V13a1 1 0 0 0-1 1v2h3v-2a1 1 0 0 0-1-1V6.739l.686-.275a.5.5 0 0 0 .025-.917z"/>
        <path d="M4.176 9.032a.5.5 0 0 0-.656.327l-.5 1.7a.5.5 0 0 0 .294.605l4.5 1.8a.5.5 0 0 0 .372 0l4.5-1.8a.5.5 0 0 0 .294-.605l-.5-1.7a.5.5 0 0 0-.656-.327L8 10.466z"/>
        </svg>
        </a></div><div class="col-4 bg-warning p-5"><a class="d-flex justify-content-center align-items-center font-weight-bold" href="admin.php?menu=admission"><span>No. Of Admissions</span><span class="ml-2  mb-1" style="font-size: 25px;">'.$admissionCount.'</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="55" height="55" fill="currentColor" class="bi bi-file-text" viewBox="0 0 16 16">
        <path d="M5 4a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1zm-.5 2.5A.5.5 0 0 1 5 6h6a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5M5 8a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1zm0 2a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1z"/>
        <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2zm10-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1"/>
        </svg>
        </a></div></div>';
      }
    function allUsers($conn)
    {
        $select = 'select * from login';
        $selectQuery = $conn->query($select);

        echo '
    <table class="table table-hover">
      <thead>
        <tr ><td colspan="4"><h4 style="padding: 10px 15px;" class="bg-primary text-uppercase text-white text-center">User\'s List</h4></td></tr>
        <tr>
          <th scope="col">_Id</th>
          <th scope="col">Username</th>
          <th scope="col">Email</th>
          <th scope="col">Password</th>
          <th scope="col">Delete</th>
        </tr>
      </thead>
      <tbody>
      ';
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<tr>
            <th scope="row">'.$row['_Id'].'</th>
            <td>'.$row['username'].'</td>
            <td>'.$row['email'].'</td>
            <td>'.$row['password'].'</td>
            <td><a href="../php/delete.php?'.$row['_Id'].'-user-login">$</a></td>
          </tr>';
        }   
        echo '</tbody>
        </table>';
    }
    function allClg($conn)
    {
        $select = 'select * from clgdet';
        $selectQuery = $conn->query($select);
        echo '<a href="../php/insert table.php">Add Colleges</a>';
        echo '
    <table class="table table-hover">
      <thead>
        <tr ><td colspan="4"><h4 style="padding: 10px 15px;" class="bg-primary text-uppercase text-white text-center">College\'s List</h4></td></tr>
        <tr>
          <th scope="col">College_Id</th>
          <th scope="col">College_Name</th>
          <th scope="col">College_Principle</th>
          <th scope="col">College_Location</th>
          <th scope="col">delete</th>
        </tr>
      </thead>
      <tbody>
      ';
        while($row = mysqli_fetch_array($selectQuery))
        {
          echo '<tr>
          <th scope="row">'.$row['clgid'].'</th>
          <td>'.$row['clgname'].'</td>
          <td>'.$row['clgprinciple'].'</td>
          <td>'.$row['clglocation'].'</td>
          <td><a href="../php/delete.php?'.$row['_Id'].'-clg-clgdet">$</a></td>
        </tr>';
        }   
        echo '</tbody>
        </table>';
      }
    function allAdmissions($conn)
    {
        $select = 'select * from admission';
        $selectQuery = $conn->query($select);
        echo '<a href="../php/insert table.php">Add Users</a>';
        echo '
    <table class="table table-hover">
      <thead>
        <tr ><td colspan="4"><h4 style="padding: 10px 15px;" class="bg-primary text-uppercase text-white text-center">ADMISSION\'s List</h4></td></tr>
        <tr>
          <th scope="col">College_Id</th>
          <th scope="col">College_Name</th>
          <th scope="col">Student Name</th>
          <th scope="col">12th Course</th>
          <th scope="col">Choosed Course</th>
          <th scope="col">delete</th>
        </tr>
      </thead>
      <tbody>
      ';
        while($row = mysqli_fetch_array($selectQuery))
        {
          echo '<tr>
          <th scope="row">'.$row['clgid'].'</th>
          <td>'.$row['clgname'].'</td>
          <td>'.$row['firstname'].' '.$row['lastname'].'</td>
          <td>'.$row['12th_course'].'</td>
          <td>'.$row['clg_course'].'</td>
          <td><a href="../php/delete.php?'.$row['_Id'].'-admission-admission">$</a></td>
        </tr>';
        }   
        echo '</tbody>
        </table>';
      }


      $menu = '';

      if(isset($_GET['menu']))
      {
        $menu = $_GET['menu'];
      }

      if($menu == 'dBoard')
      {
        dBoard($conn);
      }
      else if($menu == 'user')
      {
        allUsers($conn);
      }
      else if($menu == 'clg')
      {
        allclg($conn);
      }
      else if($menu == 'admission')
      {
        allAdmissions($conn);
      }
    ?>
        </div>
    </div>
</body>
<script>
  const clgMenu = document.getElementById('contact');
  clgMenu.classList.add('glow');

  <?php
    if(isset($_SESSION['deleteStatus'])) {
      if($_SESSION['deleteStatus'] == 200) {
        $id = $_SESSION['deletedDataId'];
        echo "alert('".ucfirst($menu)." No.$id Delete Successfully')";
      }
      else if($_SESSION['deleteStatus'] == 400) {
        echo "alert('Try Again Later')";
      }
      $_SESSION['deletedDataId'] = 0;
      $_SESSION['deleteStatus'] = 0;
    }
  ?>

</script>
</html>