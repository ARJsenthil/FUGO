<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Document</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .img a:hover .apply-now
    {
        display: block !important;
    }
    .img a:hover img
    {
        transition: all .3s ease-in-out;
        transform: scale(1.2);
    }
    .apply-now
    {
        background-color: rgb( 0, 0, 0, .3);
        z-index: 1;
        top: 0 ;
        h1
        {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: x-large;
        }
    }
        .top-select
        {
            border: 1px solid transparent;
            border-top-color: rgba(9, 190, 250, 0.6);
            border-bottom-color: rgba(9, 190, 250, 0.6);
            background-color: rgba(9, 190, 250, 0.3);
            width: 90%;
            margin: 50px auto;
            padding: 10px;
            
            select
            {
                height: 39px;
                padding: 6.5px 10px;
            }
            input
            {
                padding: 3.8px 10px;
                width: 65px;
                height: 39px;
                text-align: center;
            }
            button
            {
                font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                height: 39px;
                padding: 5px 20px; color: white; background-color: rgba(9, 190, 250);
                &:hover
                {
                    color: rgba(9, 190, 250);
                    border-color: rgba(9, 190, 250);
                    background-color: white;
                }
            }
            .span_a
            {
                font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
                font-weight: bold; font-size: large;
            }
            
        }
        .tittle
        {
            font-size: large;
            background-color: rgba(9, 190, 250);
            width: 60%;
            margin: auto;
        }
</style>
</head>
<body onload="onload()">
<?php include 'header.php';?>

<?php
      if(isset($_SESSION['admissionSucces']))
      {
        if($_SESSION['admissionSucces'] == 'success')
        {
          echo '
          <div class=" text-center px-3 py-3 rounded m-auto clearfix position-absolute" id="success" style="z-index: 1; left: 50%; top: 70px; transform: translate(-50%, 0); background-color: rgb(60, 255, 100); width:300px;">
          <h6 class="float-left mt-1 text-white" style="font-size: 17px;">ADMISSION SENDED</h6>
          <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" style="cursor: pointer;" onclick="successAlert()" class="text-white float-right bi bi-x" viewBox="0 0 16 16">
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
          </svg>
        </div>';
      $_SESSION['admissionSucces'] = 'good';
      }}
      ?>
<?php 
        // $_SESSION['tittle'];
        include '../php/db_conn.php';
        if(isset($_SESSION['userType']))
        {
        echo '<input id="userType" style="display: none;" type="text" value='.$_SESSION['userType'].' />';
        echo '<input id="userName" style="display: none;" type="text" value='.$_SESSION['uname'].' />';

        if($_SESSION['userType'] == 'student')
        {
         
        $uname = $_SESSION['uname'];
        $selectMark = "select * from login where username = '$uname' or email = '$uname'";
        $markResult = $conn->query($selectMark);
        // if(mysqli_num_row($markResult) == 1)
        // {
            $row = mysqli_fetch_array($markResult);
            $_SESSION['grade'] = $row['grade'];
        // }   
        }
        }
        if(isset($row['12th_course'])){
            $_SESSION['12th_course'] = $row['12th_course'];
            echo '<input id="12th_course" style="display: none;" type="text" value='.$row['12th_course'].' />';
        }
        ?>
    <div class="main">
        <form action="../php/selecting clg.php" method="POST" class=" top-select d-flex justify-content-center align-items-center" style="gap: 30px ;">
            <!-- <label for="clg-s"></label> -->
            <div class="filter d-flex align-items-center mr-5" style="gap: 6px;">
                <span  style="font-size: 29px;  font-weight: bold;"><i class="bi bi-filter"></i></span><span class="span_a">Filter</span> 
            </div>
            <?php
            if(isset($_SESSION['userType']))
            {
            if($_SESSION['userType'] == 'student')
            {
                echo '<div class="mark d-flex align-items-center" style="background: transparent;">
                <input type="checkbox" style="height: 16px; width: 16px;" name="mark" id="mark" disabled>
                <label for="" class="px-2 pt-2">Colleges For You</label>
                <input type="text" readonly onclick="for_you(event)" id="mark_inp" value="'.strtoupper($row['grade']).'"/>
            </div>';
            }
            }
            ?>
            <select name="selectedclg" id="clg-s" onchange="selectClg(event)">
                <option value="-1" > -- Select College --</option>
                <option id="Medical" value="Medical">Medical</option>
                <option id="Engineering" value="Engineering">Engineering</option>
                <option id="Arts" value="Arts & Science">Arts & Science</option>
                <option id="Diploma" value="Diploma">Diploma</option>
            </select>
            <select name="selectedUniversity" id="selectUniversity">
                <option value="-1" > -- Select University --</option>
                <option value="Anna University" id="Anna University">Anna University</option>
                <option value="Annamalai University" id="Annamalai University">Annamalai University</option>
                <option value="Madras University" id="Madras University">Madras University</option>
                <option value="Dr. MGR University" id="DrMGRUniversity">Dr. MGR University</option>
                <option value="Private University" id="Private University">Private University</option>
            </select>
            <button class="btn" onclick="filterCick()">Filter</button>
        </form>
        <div class="text-center">
            <?php if(isset($_SESSION['tittle'])){ $a = $_SESSION['tittle']; echo '<h4 style="padding: 10px 15px 11px 15px;" class="rounded text-white d-inline-block tittle">'.$a.'</h4>';}?>
        </div>
        <div class="row boxes" style="width: 90%; margin: auto;">

        <?php
    include '../php/db_conn.php';

    // Select All  Colleges From Table
    function allClg($conn)
    {
        $_SESSION['tittle'] = 'All Colleges';
        $select = 'select * from clgdet';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All Grade B & C Colleges
    function allBGradeClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "b" or clggrade = "c"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select All C Grade Colleges
    function allCGradeClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "c"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select Only A Grade Colleges
    function onlyAGradeClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "a"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select Only B Grade Colleges 
    function onlyBGradeClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "b"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select Only C Grade Colleges 
    function onlyCGradeClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "C"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select All  Medical Colleges
    function allMedicalClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Arts Colleges
    function allArtsClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Engineering Colleges
    function allEngineeringClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Diploma Colleges
    function allDiplomaClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "diploma"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

   
    // Select All B Grade  Medical Colleges
    function allBGradeMedicalClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and ( clggrade = "b" or clggrade = "c")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All C Grade  Medical Colleges
    function allCGradeMedicalClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "c"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All B and C Grde  Arts Colleges
    function allBGradeArtsClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clggrade = "b" or clggrade = "c" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All C Grade Arts Colleges
    function allCGradeArtsClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and clggrade = "c"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

     // Select All B Grade  Engineering Colleges
     function allBGradeEngineeringClg($conn)
     {
         $select = 'select * from clgdet where clgfield = "engineering" and ( clggrade = "b" or clggrade = "c")';
         $selectQuery = $conn->query($select);
         while($row = mysqli_fetch_array($selectQuery))
         {
             echo '<div class="box col-4 mt-4">
             <div class="clg-cont-main-div overflow-hidden">
                 <div class="img position-relative">
                     <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                         <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                         <div class="w-100 h-100 d-none position-absolute apply-now">
                             <h1>Apply Now</h1>
                         </div>     
                     </a>
                 </div>
                 <div class="clg-cont-div">
                     <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                     <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                     <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                 </div>
             </div>
         </div>';
         }   
     }

    // Select All C Grades Engineering Colleges
    function allCGradeEngineeringClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and ( clggrade = "b" or clggrade = "c")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Diploma Colleges
    function allDiplomaClgForBGradeStudents($conn)
    {
        $select = 'select * from clgdet where clgfield = "diploma" and clggrade = "c"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Diploma Colleges    
    function allAnnaUniversityClg($conn)
    {
        $select = 'select * from clgdet where ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University, Chennai" or clgaffiliattions = "Autonomous (Anna University)" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allAGradeAnnaUniversityClg($conn)
    {
        $select = 'select * from clgdet where (clggrade = "a" or clggrade = "b" or clggrade = "c") and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University, Chennai" or clgaffiliattions = "Autonomous (Anna University)" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeAnnaUniversityClg($conn)
    {
        $select = 'select * from clgdet where (clggrade = "b" or clggrade = "c") and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University, Chennai" or clgaffiliattions = "Autonomous (Anna University)" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeAnnaUniversityClg($conn)
    {
        $select = 'select * from clgdet where ( clggrade = "c") and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University, Chennai" or clgaffiliattions = "Autonomous (Anna University)" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    

    // Select All  Diploma Colleges
    function allAnnamalaiUniversityClg($conn)
    {
        $select = 'select * from clgdet where ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allAGradeAnnamalaiUniversityClg($conn)
    {
        $select = 'select * from clgdet where ( clggrade = "a" or clggrade = "b" or clggrade = "c") ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeAnnamalaiUniversityClg($conn)
    {
        $select = 'select * from clgdet where (clggrade = "b" or clggrade = "c") and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeAnnamalaiUniversityClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "c" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Diploma Colleges
    function allMadrasUniversityClg($conn)
    {
        $select = 'select * from clgdet where (clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allAGradeMadrasUniversityClg($conn)
    {
        $select = 'select * from clgdet where (clggrade = "a" or clggrade = "b" or clggrade = "c") and (clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }function allBGradeMadrasUniversityClg($conn)
    {
        $select = 'select * from clgdet where (clggrade = "b" or clggrade = "c") and (clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }function allCGradeMadrasUniversityClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "c" and (clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Diploma Colleges
    function allDrMGrUniversityClg($conn)
    {
        $select = 'select * from clgdet where (clgaffiliattions = "Dr. M.G.R. Medical University" or clgaffiliattions = "Tamil Nadu Dr. M.G.R. Medical University")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allAGradeDrMGrUniversityClg($conn)
    {
        $select = 'select * from clgdet where (clggrade = "a" or clggrade = "b" or clggrade = "c") and (clgaffiliattions = "Dr. M.G.R. Medical University" or clgaffiliattions = "Tamil Nadu Dr. M.G.R. Medical University")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeDrMGrUniversityClg($conn)
    {
        $select = 'select * from clgdet where ( clggrade = "b" or clggrade = "c") and (clgaffiliattions = "Dr. M.G.R. Medical University" or clgaffiliattions = "Tamil Nadu Dr. M.G.R. Medical University")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeDrMGrUniversityClg($conn)
    {
        $select = 'select * from clgdet where grase = "c" and (clgaffiliattions = "Dr. M.G.R. Medical University" or clgaffiliattions = "Tamil Nadu Dr. M.G.R. Medical University")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Diploma Colleges
    function allPrivateUniversityClg($conn)
    {
        $select = 'select * from clgdet where clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allAGradePrivateUniversityClg($conn)
    {
        $select = 'select * from clgdet where (clggrade = "a" or clggrade = "b" or clggrade = "c") and clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradePrivateUniversityClg($conn)
    {
        $select = 'select * from clgdet where ( clggrade = "b" or clggrade = "c") and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradePrivateUniversityClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "c" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }
    

    function allAGradeMedicalAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeMedicalAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeMedicalAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function medicalAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    
    function allAGradeEngineeringAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeEngineeringAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeEngineeringAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function engineeringAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }


    function allAGradeArtsAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeArtsAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeArtsAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function artsAnnaUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Anna University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allAGradeMedicalAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeMedicalAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeMedicalAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function medicalAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    
    function allAGradeEngineeringAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeEngineeringAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeEngineeringAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function engineeringAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }


    function allAGradeArtsAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeArtsAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeArtsAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function artsAnnamalaiUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Annamalai University" or clgaffiliattions = "annamalai University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allAGradeMedicalDrMGRUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and (clgaffiliattions = "Dr. M.G.R. Medical University" or clgaffiliattions = "Tamil Nadu Dr. M.G.R. Medical University")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeMedicalDrMGRUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and (clgaffiliattions = "Dr. M.G.R. Medical University" or clgaffiliattions = "Tamil Nadu Dr. M.G.R. Medical University")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeMedicalDrMGRUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and (clgaffiliattions = "Dr. M.G.R. Medical University" or clgaffiliattions = "Tamil Nadu Dr. M.G.R. Medical University")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function medicalDrMGRUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and (clgaffiliattions = "Dr. M.G.R. Medical University" or clgaffiliattions = "Tamil Nadu Dr. M.G.R. Medical University")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allAGradeMedicalMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeMedicalMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeMedicalMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function medicalMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    
    function allAGradeEngineeringMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeEngineeringMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeEngineeringMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function engineeringMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }


    function allAGradeArtsMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeArtsMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeArtsMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function artsMadrasUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Madras University" or clgaffiliattions = "University of Madras" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }
    
    function allAGradeMedicalPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeMedicalPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeMedicalPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "a" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function medicalPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    
    function allAGradeEngineeringPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeEngineeringPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeEngineeringPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and clggrade = "a" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function engineeringPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }


    function allAGradeArtsPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allBGradeArtsPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function allCGradeArtsPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Autonomous" or clgaffiliattions = "Deemed University" or clgaffiliattions = "Deemed" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    function artsPrivateUniversity($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clgaffiliattions = "Private University" or clgaffiliattions = "Anna University" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4 mt-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadmission.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.ucwords($row['clgname']).'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 150).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank" class="text-primary">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // echo $_SESSION['clg'];
    $clg = '';

    if(isset($_GET['clg']))
    {
        $clg = $_GET['clg'];
        $_SESSION['clg'] = $clg;
    }
    else if(isset($_SESSION['clg']))
    {
        $clg = $_SESSION['clg'];
    }

    switch($clg)
    {
        case 'allClg':
            allClg($conn);
            break;
        case 'allAGradeClg':
            allClg($conn);
            break;
        case 'allBGradeClg':
            allBGradeClg($conn);
            break;
        case 'allCGradeClg':
            allCGradeClg($conn);
            break;
        case 'onlyAGradeClg':
            onlyAGradeClg($conn);
            break;
        case 'onlyBGradeClg':
            onlyBGradeClg($conn);
            break;
        case 'OnlyCGradeClg':
            onlyCGradeClg($conn);
            break;
        case 'allMedicalClg':
            allMedicalClg($conn);
            break;
        case 'allAGradeMedicalClg':
            allMedicalClg($conn);
            break;
        case 'allBGradeMedicalClg':
            allBGradeMedicalClg($conn);
            break;
        case 'allCGradeMedicalClg':
            allCGradeMedicalClg($conn);
            break;
        case 'allEngineeringClg':
            allEngineeringClg($conn);
            break;
        case 'allAGradeEngineeringClg':
            allAGradeEngineeringClg($conn);
            break;
        case 'allBGradeEngineeringClg':
            allBGradeEngineeringClg($conn);
            break;
        case 'allCGradeEngineeringClg':
            allCGradeEngineeringClg($conn);
            break;
        case 'allArtsClg':
            allArtsClg($conn);
            break;
        case 'allAGradeArtsClg':
            allAGradeArtsClg($conn);
            break;
        case 'allBGradeArtsClg':
            allBGradeArtsClg($conn);
            break;
        case 'allCGradeArtsClg':
            allCGradeArtsClg($conn);
            break;
        case 'allDiplomaClg':
            allDiplomaClg($conn);
            break;
        case 'allAnnaUniversityClg':
            allAnnaUniversityClg($conn);
            break;
        case 'allDrMGRUniversityClg':
            allDrMGrUniversityClg($conn);
            break;
        case 'allAnnamalaiUniversityClg':
            allAnnamalaiUniversityClg($conn);
            break;
        case 'allPrivateUniversityClg':
            allPrivateUniversityClg($conn);
            break;
        case 'allMadrasUniversityClg':
            allMadrasUniversityClg($conn);
            break;
            case 'allAGradeAnnaUniversityClg':
                allAGradeAnnaUniversityClg($conn);
                break;
            case 'allBGradeAnnaUniversityClg':
                allBGradeAnnaUniversityClg($conn);
                break;
            case 'allCGradeAnnaUniversityClg':
                allCGradeAnnaUniversityClg($conn);
                break;
            case 'allAGradeDrMGRUniversityClg':
                allAGradeDrMGRUniversityClg($conn);
                break;
            case 'allBGradeDrMGRUniversityClg':
                allBGradeDrMGRUniversityClg($conn);
                break;
            case 'allCGradeDrMGRUniversityClg':
                allCGradeDrMGRUniversityClg($conn);
                break;
            case 'allAGradeAnnamalaiUniversityClg':
                allAGradeAnnamalaiUniversityClg($conn);
                break;
            case 'allBGradeAnnamalaiUniversityClg':
                allBGradeAnnamalaiUniversityClg($conn);
                break;
            case 'allCGradeAnnamalaiUniversityClg':
                allCGradeAnnamalaiUniversityClg($conn);
                break;
            case 'allAGradePrivateUniversityClg':
                allAGradePrivateUniversityClg($conn);
                break;
            case 'allBGradePrivateUniversityClg':
                allBGradePrivateUniversityClg($conn);
                break;
            case 'allCGradePrivateUniversityClg':
                allCGradePrivateUniversityClg($conn);
                break;
            case 'allAGradeMadrasUniversityClg':
                allAGradeMadrasUniversityClg($conn);
                break;
            case 'allBGradeMadrasUniversityClg':
                allBGradeMadrasUniversityClg($conn);
                break;
            case 'allCGradeMadrasUniversityClg':
                allCGradeMadrasUniversityClg($conn);
                break;
        case 'allAGradeMedicalAnnaUniversity':
            allAGradeMedicalAnnaUniversity($conn);
            break;
        case 'allBGradeMedicalAnnaUniversity':
            allBGradeMedicalAnnaUniversity($conn);
            break;
        case 'allCGradeMedicalAnnaUniversity':
            allCGradeMedicalAnnaUniversity($conn);
            break;
        case 'medicalAnnaUniversity':
            medicalAnnaUniversity($conn);
            break;
        case 'allAGradeEngineeringAnnaUniversity':
            allAGradeEngineeringAnnaUniversity($conn);
            break;
        case 'allBGradeEngineeringAnnaUniversity':
            allBGradeEngineeringAnnaUniversity($conn);
            break;
        case 'allCGradeEngineeringAnnaUniversity':
            allCGradeEngineeringAnnaUniversity($conn);
            break;
        case 'engineeringAnnaUniversity':
            engineeringAnnaUniversity($conn);
            break;
        case 'allAGradeArtsAnnaUniversity':
            allAGradeArtsAnnaUniversity($conn);
            break;
        case 'allBGradeArtsAnnaUniversity':
            allBGradeArtsAnnaUniversity($conn);
            break;
        case 'allCGradeArtsAnnaUniversity':
            allCGradeArtsAnnaUniversity($conn);
            break;
        case 'artsAnnaUniversity':
            artsAnnaUniversity($conn);
            break;
        case 'allAGradeMedicalAnnamalaiUniversity':
            allAGradeMedicalAnnamalaiUniversity($conn);
            break;
        case 'allBGradeMedicalAnnamalaiUniversity':
            allBGradeMedicalAnnamalaiUniversity($conn);
            break;
        case 'allCGradeMedicalAnnamalaiUniversity':
            allCGradeMedicalAnnamalaiUniversity($conn);
            break;
        case 'medicalAnnamalaiUniversity':
            medicalAnnamalaiUniversity($conn);
            break;
        case 'allAGradeEngineeringAnnamalaiUniversity':
            allAGradeEngineeringAnnamalaiUniversity($conn);
            break;
        case 'allBGradeEngineeringAnnamalaiUniversity':
            allBGradeEngineeringAnnamalaiUniversity($conn);
            break;
        case 'allCGradeEngineeringAnnamalaiUniversity':
            allCGradeEngineeringAnnamalaiUniversity($conn);
            break;
        case 'engineeringAnnamalaiUniversity':
            engineeringAnnamalaiUniversity($conn);
            break;
        case 'allAGradeArtsAnnamalaiUniversity':
            allAGradeArtsAnnamalaiUniversity($conn);
            break;
        case 'allBGradeArtsAnnamalaiUniversity':
            allBGradeArtsAnnamalaiUniversity($conn);
            break;
        case 'allCGradeArtsAnnamalaiUniversity':
            allCGradeArtsAnnamalaiUniversity($conn);
            break;
        case 'artsAnnamalaiUniversity':
            artsAnnamalaiUniversity($conn);
            break;
            case 'allAGradeMedicalDrMGRUniversity':
            allAGradeMedicalDrMGRUniversity($conn);
            break;
        case 'allBGradeMedicalDrMGRUniversity':
            allBGradeMedicalDrMGRUniversity($conn);
            break;
        case 'allCGradeMedicalDrMGRUniversity':
            allCGradeMedicalDrMGRUniversity($conn);
            break;
        case 'medicalDrMGRUniversity':
            medicalDrMGRUniversity($conn);
            break;
        case 'allAGradeEngineeringDrMGRUniversity':
            allAGradeEngineeringDrMGRUniversity($conn);
            break;
        case 'allBGradeEngineeringDrMGRUniversity':
            allBGradeEngineeringDrMGRUniversity($conn);
            break;
        case 'allCGradeEngineeringDrMGRUniversity':
            allCGradeEngineeringDrMGRUniversity($conn);
            break;
        case 'allAGradeMedicalDrMGRUniversity':
            allAGradeMedicalDrMGRUniversity($conn);
            break;
        case 'allBGradeMedicalDrMGRUniversity':
            allBGradeMedicalDrMGRUniversity($conn);
            break;
        case 'allCGradeMedicalDrMGRUniversity':
            allCGradeMedicalDrMGRUniversity($conn);
            break;
        case 'artsDrMGRUniversity':
            artsDrMGRUniversity($conn);
            break;
        case 'allAGradeDrMGRUniversityClg':
            allAGradeMedicalDrMGRUniversity($conn);
            break;
        case 'allBGradeDrMGRUniversityClg':
            allBGradeMedicalDrMGRUniversity($conn);
            break;
        case 'allCGradeDrMGRUniversityClg':
            allCGradeMedicalDrMGRUniversity($conn);
            break;
        case 'allAGradeMedicalMadrasUniversity':
            allAGradeMedicalMadrasUniversity($conn);
            break;
        case 'allBGradeMedicalMadrasUniversity':
            allBGradeMedicalMadrasUniversity($conn);
            break;
        case 'allCGradeMedicalMadrasUniversity':
            allCGradeMedicalMadrasUniversity($conn);
            break;
        case 'medicalMadrasUniversity':
            medicalMadrasUniversity($conn);
            break;
        case 'allAGradeEngineeringMadrasUniversity':
            allAGradeEngineeringMadrasUniversity($conn);
            break;
        case 'allBGradeEngineeringMadrasUniversity':
            allBGradeEngineeringMadrasUniversity($conn);
            break;
        case 'allCGradeEngineeringMadrasUniversity':
            allCGradeEngineeringMadrasUniversity($conn);
            break;
        case 'engineeringMadrasUniversity':
            engineeringMadrasUniversity($conn);
            break;
        case 'allAGradeArtsMadrasUniversity':
            allAGradeArtsMadrasUniversity($conn);
            break;
        case 'allBGradeArtsMadrasUniversity':
            allBGradeArtsMadrasUniversity($conn);
            break;
        case 'allCGradeArtsMadrasUniversity':
            allCGradeArtsMadrasUniversity($conn);
            break;
        case 'artsMadrasUniversity':
            artsMadrasUniversity($conn);
            break;
        case 'allAGradeMedicalPrivateUniversity':
            allAGradeMedicalPrivateUniversity($conn);
            break;
        case 'allBGradeMedicalPrivateUniversity':
            allBGradeMedicalPrivateUniversity($conn);
            break;
        case 'allCGradeMedicalPrivateUniversity':
            allCGradeMedicalPrivateUniversity($conn);
            break;
        case 'medicalPrivateUniversity':
            medicalPrivateUniversity($conn);
            break;
        case 'allAGradeEngineeringPrivateUniversity':
            allAGradeEngineeringPrivateUniversity($conn);
            break;
        case 'allBGradeEngineeringPrivateUniversity':
            allBGradeEngineeringPrivateUniversity($conn);
            break;
        case 'allCGradeEngineeringPrivateUniversity':
            allCGradeEngineeringPrivateUniversity($conn);
            break;
        case 'engineeringPrivateUniversity':
            engineeringPrivateUniversity($conn);
            break;
        case 'allAGradeArtsPrivateUniversity':
            allAGradeArtsPrivateUniversity($conn);
            break;
        case 'allBGradeArtsPrivateUniversity':
            allBGradeArtsPrivateUniversity($conn);
            break;
        case 'allCGradeArtsPrivateUniversity':
            allCGradeArtsPrivateUniversity($conn);
            break;
        case 'artsPrivateUniversity':
            artsPrivateUniversity($conn);
            break;

        default:
            allClg($conn);

      
    }

    
    // allAnnaUniversityClg($conn);
    // allClg($conn);
?>
        </div>
    </div>
    <?php include 'footer.php';?>
</body>
<script>
    // function onloadSelectingClg()
    // {
    //     var a  = localStorage.getItem('tot_per');
    //     if(a)
    //     {
    //         document.getElementById('mark_inp').value = a+'%';
    //     }
    // }
        <?php 
        if(isset($_SESSION['userType']))
        {
        if($_SESSION['userType'] == 'student')
        {
        echo "
        function for_you(event)
        {
            var a = event.target.value;
            if(a == 0)
            {
                window.location = 'for you.php';
            }
            else
            {
                return true;
                
            }
        }
        ";
        }
            echo "
            
            ";
    }
        if(isset($row['12th_course'])){
            echo "
            function onload()
        {
            if(document.getElementById('12th_course').value == 'group-a'){
                document.getElementById('Medical').disabled = false;
            }
            else if(document.getElementById('12th_course').value == 'group-b'){
            document.getElementById('Medical').disabled = true;
            console.log('123123')
            }
            else if(document.getElementById('12th_course').value == 'group-c'){
                document.getElementById('Medical').disabled = true;
                // document.getElementById('Medical').disabled = true;
            }
            var mark_inp = document.getElementById('mark_inp');
            var mark = document.getElementById('mark');
            if(mark_inp.value != 'A' && mark_inp.value != 'B' && mark_inp.value != 'C')
            {
                mark.disabled = true;
            }
            else
            {
                mark.disabled = false;
            }
        }";
    }
        ?>
    function selectClg(event)
    {
        if(event.target.value == 'Diploma')
        {
            document.getElementById('selectUniversity').disabled = true;
            document.getElementById('mark_inp').disabled = true;
            document.getElementById('mark').disabled = true;
            document.getElementById('DrMGRUniversity').disabled = false;
        }
        else if(event.target.value == 'Medical')
        {
            document.getElementById('Anna University').disabled = true;
            document.getElementById('selectUniversity').disabled = false;
            document.getElementById('mark_inp').disabled = false;
            document.getElementById('mark').disabled = false;
            document.getElementById('DrMGRUniversity').disabled = false;
        }
        else if(event.target.value == 'Engineering' || event.target.value == 'Arts & Science')
        {
            document.getElementById('DrMGRUniversity').disabled = true;
            document.getElementById('Anna University').disabled = false;
            document.getElementById('selectUniversity').disabled = false;
            document.getElementById('mark_inp').disabled = false;
            document.getElementById('mark').disabled = false;
        }
        else
        {
            document.getElementById('DrMGRUniversity').disabled = false;
            document.getElementById('selectUniversity').disabled = false;
            document.getElementById('mark_inp').disabled = false;
            document.getElementById('Anna University').disabled = false;
            document.getElementById('mark').disabled = false;
        }

    }
  function successAlert(){document.getElementById('success').style = "display: none;"}
    const clgMenu = document.getElementById('selectingClg');
    clgMenu.classList.add('glow');
</script>
</html>