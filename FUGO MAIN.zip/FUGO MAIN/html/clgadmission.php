<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/admission.css">
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css">
    <style>
        
.clg-det{
    display: block;
    height: 100%;
    width: 35%;
    img
    a{
        height: 300px;
    }
        p, span
        {
            font-size: 14px !important;
        }

        .clg-det-0
        {
            font-size: 14px !important;
            display: grid !important;
            gap: 10px !important;
        }
        .clg-det-0 div
        {
            gap: 10px !important;

        }
        .b
        {
            display: inline-block;
            width: 110px !important;
        }
}
.adm-form-1{
    padding: 5px;   
    display: flex;
    gap: 5px;
    background-color: rgba(9, 190, 250, 0.9);
    overflow: hidden;
    height: 1190px !important;
}
.clg-adm{
    width: 65%;
    padding: 10px 15px;
    overflow-y: scroll;
}
        h2, h3, h4, h5
        {   
            font-size: 15px !important;
            font-weight: bold !important;
        }
        .h-2
        {
            font-size: 25px;
            text-align: center;
        }
        input, select
        {
            height: 39px !important;
            padding: 10px !important;
        }
        .adm-form-1
        {
            height: 1000px;
        }
        .ad-h1
        {
            position: sticky;
            top: 0px;
        }
    </style>
    <title>Admission</title>
</head>
<body>
<?php include 'header.php';?>
    <?php
    $clgid =  $_GET["clgid"];
    include '../php/db_conn.php';
        $select = 'select * from clgdet where clgid = "'.$clgid.'"';
        $selectQuery = $conn->query($select);
        $row = mysqli_fetch_array($selectQuery);
    ?>
    <form action="../php/clgadmission.php?<?php echo 'clgid='.$row['clgid'].'&clgfield='.$row['clgfield']?>" method="POST" class="adm-form bg-dark p-0">
        <!-- <h1 class="title">Final destination for your Admission!</h1> -->
        <section class="adm-form-1 p-0">
            <div class="clg-det bg-light">
                <div class="clg-img">
                    <img src="<?php echo $row['clgimgsrc']?>" alt="img" class="clg-img-1">
                </div>
                <div class="clg-name">
                    <h4 class="clg-name-1 p-3"><?php echo ucwords($row['clgname'])?></h4>
                </div>
                <div class="clg-info">
                    <p class="clg-info-1"> <?php echo $row['clgdet']?></p>
                </div>
                <div class="clg-det-0 p-3 border-top d-grid" style="padding-top: 65px !important;">
                    <div class="clg-det-1">
                    <p><b class="b">Affiliations</b>: <span class="det"><?php echo $row['clgaffiliattions']?></span></p>
                    <p><b class="b">Website</b>: <span class="det"><a class="btn-link" href="https://<?php echo $row['clgwebsite']?>" target="_blank"><?php echo $row['clgwebsite']?></a></span></p>
                    <p><b class="b">Location</b>: <span class="det"><?php echo $row['clglocation']?></span></p>
                    <p><b class="b">Principle</b>: <span class="det"> <?php echo $row['clgprinciple']?></span></p>
                    </div>
                    <div class="clg-det-2">
                    <p><b class="b">Type</b>: <span class="det"> <?php echo $row['clgtype']?></span></p>
                    <p><b class="b">Campus</b>: <span class="det"><?php echo $row['clgcampus']?></span></p>
                    <p><b class="b">Established</b>: <span class="det"> <?php echo $row['clgestablished']?></span></p>
                    <p><b class="b">Fees</b>: <span class="det"> Rs:50000</span></p>
                    </div>
                </div>
            </div>
            <!-- <div class="border" style="background-color: black; width: 5px; height: 100%;"></div> -->
            <div class="clg-adm bg-light overflow-hidden">
                <h1 class="h-2 ad-h1 w-100">Admission Form</h1>
                <div class="">
                    <h2>Name</h2>
                    <section class=" col-2-parent">
                        <input required type="text" placeholder="Firstname"  name="firstname"  class="col-2-child ">
                        <!-- <input required type="text" placeholder="Middle name" name="Middlename"  class="col-2-child "> -->
                        <input required type="text" placeholder="Last name" name="lastname"  class="col-2-child ">
                    </section>
                </div>
                <br>
                <div class="">
                    <h2>Birth Date</h2>
                    <section class="col-3-parent">
                        <select id="day" name="date" class="col-3-child">
                            <option value="0">please select a date </option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">27</option>
                            <option value="28">28</option>
                            <option value="29">29</option>
                            <option value="30">30</option>
                            <option value="31">31</option>
                        </select>
                        <select id="month" name="month" class="col-3-child">
                            <option>please select a month </option>
                            <option value="jan">January</option>
                            <option value="jan">February</option>
                            <option value="jan">March</option>
                            <option value="jan">April</option>
                            <option value="jan">May</option>
                            <option value="jan">June</option>
                            <option value="jan">July</option>
                            <option value="jan">August</option>
                            <option value="jan">September</option>
                            <option value="jan">October</option>
                            <option value="jan">November</option>
                            <option value="jan">December</option>
                        </select>
                        <select id="year" name="year" class="col-3-child">
                            <option slected>Please select a year </option>
                        </select>
                    </section>
                </div>
                <br>
                <div class="d-flex w-100">        
                    <section class="col-2-parent" style="align-items: center;">
                        <section class="gender " style="width: 50% !important;">
                            <div class="col-3-parent align-items-center">
                                <h4 class="m-0">Gender:</h4>
                                <div class="gen d-flex"><input required type="radio" name="gender" id="male" value="male" class="gend"><label class="m-0 mt-2 ml-1" for="">Male</label></div>
                                <div class="gen d-flex"><input required type="radio" class="gend"name="gender" id="female" value="female"> <label class="m-0 mt-2 ml-1" for="">Female</label></div>
                            </div>
                        </section>
                        <section class="" style="width: 50%;">
                            <div class="">
                                <h4>Of which country are you a citizen?</h4>
                                <select name="country" id="country" class="country">
                                    <option value="">Select a country</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Åland Islands">Åland Islands</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                    <option value="Argentina">Argentina</option>
                                    <option value="Armenia">Armenia</option>
                                    <option value="Aruba">Aruba</option>
                                    <option value="Australia">Australia</option>
                                    <option value="Austria">Austria</option>
                                    <option value="Azerbaijan">Azerbaijan</option>
                                    <option value="Bahamas">Bahamas</option>
                                    <option value="Bahrain">Bahrain</option>
                                    <option value="Bangladesh">Bangladesh</option>
                                    <option value="Barbados">Barbados</option>
                                    <option value="Belarus">Belarus</option>
                                    <option value="Belgium">Belgium</option>
                                    <option value="Belize">Belize</option>
                                    <option value="Benin">Benin</option>
                                    <option value="Bermuda">Bermuda</option>
                                    <option value="Bhutan">Bhutan</option>
                                    <option value="Bolivia">Bolivia</option>
                                    <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                    <option value="Botswana">Botswana</option>
                                    <option value="Bouvet Island">Bouvet Island</option>
                                    <option value="Brazil">Brazil</option>
                                    <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                    <option value="Brunei Darussalam">Brunei Darussalam</option>
                                    <option value="Bulgaria">Bulgaria</option>
                                    <option value="Burkina Faso">Burkina Faso</option>
                                    <option value="Burundi">Burundi</option>
                                    <option value="Cambodia">Cambodia</option>
                                    <option value="Cameroon">Cameroon</option>
                                    <option value="Canada">Canada</option>
                                    <option value="Cape Verde">Cape Verde</option>
                                    <option value="Cayman Islands">Cayman Islands</option>
                                    <option value="Central African Republic">Central African Republic</option>
                                    <option value="Chad">Chad</option>
                                    <option value="Chile">Chile</option>
                                    <option value="China">China</option>
                                    <option value="Christmas Island">Christmas Island</option>
                                    <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                    <option value="Colombia">Colombia</option>
                                    <option value="Comoros">Comoros</option>
                                    <option value="Congo">Congo</option>
                                    <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                                    <option value="Cook Islands">Cook Islands</option>
                                    <option value="Costa Rica">Costa Rica</option>
                                    <option value="Cote D'ivoire">Cote D'ivoire</option>
                                    <option value="Croatia">Croatia</option>
                                    <option value="Cuba">Cuba</option>
                                    <option value="Curaçao">Curaçao</option>
                                    <option value="Cyprus">Cyprus</option>
                                    <option value="Czech Republic">Czech Republic</option>
                                    <option value="Denmark">Denmark</option>
                                    <option value="Djibouti">Djibouti</option>
                                    <option value="Dominica">Dominica</option>
                                    <option value="Dominican Republic">Dominican Republic</option>
                                    <option value="Ecuador">Ecuador</option>
                                    <option value="Egypt">Egypt</option>
                                    <option value="El Salvador">El Salvador</option>
                                    <option value="Equatorial Guinea">Equatorial Guinea</option>
                                    <option value="Eritrea">Eritrea</option>
                                    <option value="Estonia">Estonia</option>
                                    <option value="Ethiopia">Ethiopia</option>
                                    <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                    <option value="Faroe Islands">Faroe Islands</option>
                                    <option value="Fiji">Fiji</option>
                                    <option value="Finland">Finland</option>
                                    <option value="France">France</option>
                                    <option value="French Guiana">French Guiana</option>
                                    <option value="French Polynesia">French Polynesia</option>
                                    <option value="French Southern Territories">French Southern Territories</option>
                                    <option value="Gabon">Gabon</option>
                                    <option value="Gambia">Gambia</option>
                                    <option value="Georgia">Georgia</option>
                                    <option value="Germany">Germany</option>
                                    <option value="Ghana">Ghana</option>
                                    <option value="Gibraltar">Gibraltar</option>
                                    <option value="Greece">Greece</option>
                                    <option value="Greenland">Greenland</option>
                                    <option value="Grenada">Grenada</option>
                                    <option value="Guadeloupe">Guadeloupe</option>
                                    <option value="Guam">Guam</option>
                                    <option value="Guatemala">Guatemala</option>
                                    <option value="Guernsey">Guernsey</option>
                                    <option value="Guinea">Guinea</option>
                                    <option value="Guinea-bissau">Guinea-bissau</option>
                                    <option value="Guyana">Guyana</option>
                                    <option value="Haiti">Haiti</option>
                                    <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                                    <option value="Honduras">Honduras</option>
                                    <option value="Hong Kong">Hong Kong</option>
                                    <option value="Hungary">Hungary</option>
                                    <option value="Iceland">Iceland</option>
                                    <option value="India">India</option>
                                    <option value="Indonesia">Indonesia</option>
                                    <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                    <option value="Iraq">Iraq</option>
                                    <option value="Ireland">Ireland</option>
                                    <option value="Isle of Man">Isle of Man</option>
                                    <option value="Israel">Israel</option>
                                    <option value="Italy">Italy</option>
                                    <option value="Jamaica">Jamaica</option>
                                    <option value="Japan">Japan</option>
                                    <option value="Jersey">Jersey</option>
                                    <option value="Jordan">Jordan</option>
                                    <option value="Kazakhstan">Kazakhstan</option>
                                    <option value="Kenya">Kenya</option>
                                    <option value="Kiribati">Kiribati</option>
                                    <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                    <option value="Korea, Republic of">Korea, Republic of</option>
                                    <option value="Kuwait">Kuwait</option>
                                    <option value="Kyrgyzstan">Kyrgyzstan</option>
                                    <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                    <option value="Latvia">Latvia</option>
                                    <option value="Lebanon">Lebanon</option>
                                    <option value="Lesotho">Lesotho</option>
                                    <option value="Liberia">Liberia</option>
                                    <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                    <option value="Liechtenstein">Liechtenstein</option>
                                    <option value="Lithuania">Lithuania</option>
                                    <option value="Luxembourg">Luxembourg</option>
                                    <option value="Macao">Macao</option>
                                    <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                                    <option value="Madagascar">Madagascar</option>
                                    <option value="Malawi">Malawi</option>
                                    <option value="Malaysia">Malaysia</option>
                                    <option value="Maldives">Maldives</option>
                                    <option value="Mali">Mali</option>
                                    <option value="Malta">Malta</option>
                                    <option value="Marshall Islands">Marshall Islands</option>
                                    <option value="Martinique">Martinique</option>
                                    <option value="Mauritania">Mauritania</option>
                                    <option value="Mauritius">Mauritius</option>
                                    <option value="Mexico">Mexico</option>
                                    <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                    <option value="Moldova, Republic of">Moldova, Republic of</option>
                                    <option value="Monaco">Monaco</option>
                                    <option value="Mongolia">Mongolia</option>
                                    <option value="Montenegro">Montenegro</option>
                                    <option value="Montserrat">Montserrat</option>
                                    <option value="Morocco">Morocco</option>
                                    <option value="Mozambique">Mozambique</option>
                                    <option value="Myanmar">Myanmar</option>
                                    <option value="Namibia">Namibia</option>
                                    <option value="Nauru">Nauru</option>
                                    <option value="Nepal">Nepal</option>
                                    <option value="Netherlands">Netherlands</option>
                                    <option value="New Caledonia">New Caledonia</option>
                                    <option value="New Zealand">New Zealand</option>
                                    <option value="Nicaragua">Nicaragua</option>
                                    <option value="Niger">Niger</option>
                                    <option value="Nigeria">Nigeria</option>
                                    <option value="Niue">Niue</option>
                                    <option value="Norfolk Island">Norfolk Island</option>
                                    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                    <option value="Norway">Norway</option>
                                    <option value="Oman">Oman</option>
                                    <option value="Pakistan">Pakistan</option>
                                    <option value="Palau">Palau</option>
                                    <option value="Palestine, State of">Palestine, State of</option>
                                    <option value="Panama">Panama</option>
                                    <option value="Papua New Guinea">Papua New Guinea</option>
                                    <option value="Paraguay">Paraguay</option>
                                    <option value="Peru">Peru</option>
                                    <option value="Philippines">Philippines</option>
                                    <option value="Pitcairn">Pitcairn</option>
                                    <option value="Poland">Poland</option>
                                    <option value="Portugal">Portugal</option>
                                    <option value="Puerto Rico">Puerto Rico</option>
                                    <option value="Qatar">Qatar</option>
                                    <option value="Réunion">Réunion</option>
                                    <option value="Romania">Romania</option>
                                    <option value="Russian Federation">Russian Federation</option>
                                    <option value="Rwanda">Rwanda</option>
                                    <option value="Saint Barthélemy">Saint Barthélemy</option>
                                    <option value="Saint Helena, Ascension and Tristan da Cunha">Saint Helena, Ascension and Tristan da Cunha</option>
                                    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                    <option value="Saint Lucia">Saint Lucia</option>
                                    <option value="Saint Martin (French part)">Saint Martin (French part)</option>
                                    <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                    <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                    <option value="Samoa">Samoa</option>
                                    <option value="San Marino">San Marino</option>
                                    <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                    <option value="Saudi Arabia">Saudi Arabia</option>
                                    <option value="Senegal">Senegal</option>
                                    <option value="Serbia">Serbia</option>
                                    <option value="Seychelles">Seychelles</option>
                                    <option value="Sierra Leone">Sierra Leone</option>
                                    <option value="Singapore">Singapore</option>
                                    <option value="Sint Maarten (Dutch part)">Sint Maarten (Dutch part)</option>
                                    <option value="Slovakia">Slovakia</option>
                                    <option value="Slovenia">Slovenia</option>
                                    <option value="Solomon Islands">Solomon Islands</option>
                                    <option value="Somalia">Somalia</option>
                                    <option value="South Africa">South Africa</option>
                                    <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                                    <option value="South Sudan">South Sudan</option>
                                    <option value="Spain">Spain</option>
                                    <option value="Sri Lanka">Sri Lanka</option>
                                    <option value="Sudan">Sudan</option>
                                    <option value="Suriname">Suriname</option>
                                    <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                    <option value="Swaziland">Swaziland</option>
                                    <option value="Sweden">Sweden</option>
                                    <option value="Switzerland">Switzerland</option>
                                    <option value="Syrian Arab Republic">Syria</option>
                                    <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                    <option value="Tajikistan">Tajikistan</option>
                                    <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                    <option value="Thailand">Thailand</option>
                                    <option value="Timor-Leste">Timor-Leste</option>
                                    <option value="Togo">Togo</option>
                                    <option value="Tokelau">Tokelau</option>
                                    <option value="Tonga">Tonga</option>
                                    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                    <option value="Tunisia">Tunisia</option>
                                    <option value="Turkey">Turkey</option>
                                    <option value="Turkmenistan">Turkmenistan</option>
                                    <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                    <option value="Tuvalu">Tuvalu</option>
                                    <option value="Uganda">Uganda</option>
                                    <option value="Ukraine">Ukraine</option>
                                    <option value="United Arab Emirates">United Arab Emirates</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="United States">United States</option>
                                    <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                    <option value="Uruguay">Uruguay</option>
                                    <option value="Uzbekistan">Uzbekistan</option>
                                    <option value="Vanuatu">Vanuatu</option>
                                    <option value="Venezuela, Bolivarian Republic of">Venezuela, Bolivarian Republic of</option>
                                    <option value="Viet Nam">Vietnam</option>
                                    <option value="Virgin Islands, British">Virgin Islands, British</option>
                                    <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                    <option value="Wallis and Futuna">Wallis and Futuna</option>
                                    <option value="Western Sahara">Western Sahara</option>
                                    <option value="Yemen">Yemen</option>
                                    <option value="Zambia">Zambia</option>
                                    <option value="Zimbabwe">Zimbabwe</option>
                                </select>
                            </div>
                        </section>
                    </section>
                </div>
                <br>
                <section class="grid-2">
                    <div class="number">
                        <h4>Phone</h4>
                        <input required type="number"  placeholder="+91 000 00 00 000" class="phone" name="phone">
                    </div>
                    <div class="mail">
                        <h4>E-mail address</h4>
                        <input required type="email" name="email" id="email" placeholder="fugo@gmail.com" class="mail">
                    </div>
                </section>
                <br>
                <section class="address">
                    <h3>Address</h3>
                    <textarea name="address" id="address" cols="30" rows="10" class="add-1"></textarea>
                </section>
                <br>
                <section class="grid-2">
                    <div class="number">
                    <h4>City</h4>
                    <input required type="text" id="city" class="phone" name="city" placeholder="enter your city">
                    </div>
                    <div class="mail">
                    <h4>State</h4>   
                    <input required type="text" id="state" class="mail" name="state" placeholder="enter your state">
                    </div>
                </section>
                <br>
                <h1 class="h-2">Education</h1>
                <br>
                <section class="grid-2">
                    <div class="number">
                        <h4>High school or Equivalent Name</h4>
                        <input required type="text" class="phone" name="school_name">            
                    </div>
                    <div class="mail">
                        <h4>Graduation Date</h4>
                        <input required type="date" class="mail" name="graduation_date">            
                    </div>
                </section>
                <br>
                <h3 class="sch-adr">School Address</h3>
                <section class="grid-2">
                    <div class="number">
                    <h4>City</h4>
                    <input required type="text" name="school_city" id="city" class="phone" placeholder="enter your city">
                    </div>
                    <div class="mail">
                    <h4>State</h4>   
                    <input required type="text" name="school_state" id="state" class="mail" placeholder="enter your state">
                    </div>
                </section>
                <br>
                <section class="grid-2">
                    <div class="number">
                        <h4>Country</h4>
                        <input required type="text" name="school_country" id="country" class="phone">
                        </div>
                        <div class="mail">
                        <h4>Register number</h4>   
                        <input required type="text" name="register_number" id="state" class="mail" placeholder="enter your register number">
                        </div>
                </section>
                <br>
                <div class="col-2-parent">
                    <select name="12th_course" class="w-100 text-center" id="">
                        <?php
                        $Group_12th = "";
                        if(isset($_SESSION['12th_course'])){
                            if($_SESSION['12th_course'] == 'group-a')
                            {
                                $Group_12th =  'Biology';
                            }
                            else if($_SESSION['12th_course'] == 'group-b')
                            {
                                $Group_12th =  'Computer Science';
                            }
                            else if($_SESSION['12th_course'] == 'group-c')
                            {
                                $Group_12th =  'Commerce';
                            }
                            else
                            {
                                $Group_12th =  'Select Your 12th Course';
                            }
                        }
                        else
                        {
                            $Group_12th =  'Select Your 12th Course';
                        }
                        echo "<option value='$Group_12th'>$Group_12th</option>";  
                        ?>
                    </select>
                    <select name="degree" class="w-100 text-center" id="">
                        <option value="-1" class="">Choose Your Degree</option>
                        <?php 
                            if($row['clgfield'] == 'medical')
                            {
                                echo '
                                <option value="MBBS" class="">MBBS</option>
                                <option value="BSC" class="">BSC</option>
                                <option value="MSC" class="">MSC</option>
                                ';
                            }
                            else if($row['clgfield'] == 'engineering')
                            {
                                echo '
                                <option value="BE" class="">BE</option>
                                <option value="BE.(CS)" class="">BE.(CS)</option>
                                <option value="BE.(Mech)" class="">BE.(Mech)</option>
                                <option value="BE.(EEE)" class="">BE.(EEE)</option>
                                <option value="BE.(EC)" class="">BE.(EC)</option>
                                <option value="B.Tech" class="">B.Tech</option>
                                <option value="ME" class="">ME</option>
                                <option value="ME.(CS)" class="">ME.(CS)</option>
                                <option value="ME.(Mech)" class="">ME.(Mech)</option>
                                <option value="ME.(EEE)" class="">ME.(EEE)</option>
                                <option value="ME.(EC)" class="">ME.(EC)</option>
                                <option value="M.Tech" class="">M.Tech</option>
                                ';
                            }
                            else if($row['clgfield'] == 'arts')
                            {
                                echo '
                                <option value="BCA" class="">BCA</option>
                                <option value="BSC" class="">BSC</option>
                                <option value="B.Com" class="">B.Com</option>
                                <option value="B.B.A" class="">B.B.A</option>
                                <option value="MCA" class="">MCA</option>
                                <option value="MSC" class="">MSC</option>
                                <option value="M.B.A" class="">M.B.A</option>
                                ';
                            }
                            else if($row['clgfield'] == 'diploma')
                            {
                                echo '
                                <option value="Diploma in (ME)" class="">Diploma in (ME)</option>
                                <option value="Diploma in (CS)" class="">Diploma in (CS)</option>
                                <option value="Diploma in (EEE)" class="">Diploma in (EEE)</option>
                                ';
                            }
                        ?>
                    </select>
                </div>
                <br>
                <section class="btn mb-5 w-100 p-0">
                    <div class=" w-100">
                        <input type="submit" name="submit" value="Submit" class="sub btn-primary w-100 p-2 mb-2 rounded">
                    </div>
                    <div class="btn-1 w-100">
                        <a href="selecting clg.php" class="back w-100 btn-link">Back</a>
                    </div>
                </section>
            </div>
        </section>
    </form>
    <?php include 'footer.php';?>
</body>
<script>
  const clgMenu = document.getElementById('selectingClg');
  clgMenu.classList.add('glow');
        var currentYear = new Date().getFullYear();
        var startYear = 1920;
        var select = document.getElementById('year');
        for (var i = currentYear; i >= startYear; i--) {
            var opt = document.createElement('option');
            opt.value = i;
            opt.innerHTML = i;
            select.appendChild(opt);
        }
    </script>
</html>