<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        td
        {
            text-align: center;
            min-width: 150px;

            
            .m
            {
                border: none;
                outline: none;
                width: 100%;
                text-align: center;
            }
        }

        .test
        {
            display: none;
        }

        .btns
        {
            td
            {
                background-color: rgb(1, 116, 211);
                padding: 0%;
                /* border-color: white; */
            }
            td input
            {
                background-color: transparent;
                color: white;
                min-width: 149px;
                min-height: 49px;
                &:hover
                {
                    color: black;
                    background-color: white;
                    border-color: blue;
                }
            }
        }

        .for-you
        {
            display: grid;
            gap: 45px;
            justify-content: center;
            align-items: center;
        }
        /* #gsl
        {

        }
        .table_div
        {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        } */

        .output
        {
            font-weight: bold;
            font-size: x-large;
            display: flex;
            gap: 45px;
            justify-content: center;
        }

        footer
        {
            margin-top: 45px;
        }
        
    </style>
    <title>Document</title>
</head>
<body onload="onloadFunction()">
<?php include 'header.php';?>
    <form class="for-you" method="POST" action="../php/for you.php">
        <h1 class="text-center pt-3 pb-1">PERCENTAGE CALCULATION</h1>
        <div style="display: flex; gap: 6px; justify-content: center; align-items: center;">
            <label for="group">Select Your 12<sup>th</sup> Group</label>
            <select name="group" id="gsl" style="padding: 5px 5px 5px 10px;" class="mb-1" onchange="selectedGroup(event)">
                <option value="-1">-- Select --</option>
                <option value="group-a">Biology</option>
                <option value="group-b">Computer Science</option>
                <option value="group-c">Commerce</option>
            </select>
        </div>
        <div class="" >
            <div class="d-table m-auto table_div">
            <table border="1" id="" cellpadding="10">
                <tr> 
                    <td colspan="1" class="p-2 text-center">S.No.</td><td  colspan="1" class="p-2 text-center">Subject</td><td colspan="1"  class="p-2 text-center">Marks</td>
                </tr>
                <tr id="dummy">
                    <td colspan="3" class="p-3">- - -</td>
                </tr>
                <tr id="r_1" class="test">
                    <td>01</td><td id="s_1"></td><td><input type="number" min="35" max="100" required minlength="2" class="m" id="m1" placeholder="Enter Your Mark"/></td>
                </tr>
                <tr id="r_2" class="test">
                    <td>02</td><td id="s_2"></td><td><input type="number" min="35" max="100" required minlength="2" class="m" id="m2" placeholder="Enter Your Mark"/></td>
                </tr>
                <tr id="r_3" class="test">
                    <td>03</td><td id="s_3"></td><td><input type="number" min="35" max="100" required minlength="2" class="m" id="m3" placeholder="Enter Your Mark"/></td>
                </tr>
                <tr id="r_4" class="test">
                    <td>04</td><td id="s_4"></td><td><input type="number" min="35" max="100" required minlength="2" class="m" id="m4" placeholder="Enter Your Mark"/></td>
                </tr>
                <tr id="r_5" class="test">
                    <td>05</td><td id="s_5"></td><td><input type="number" min="35" max="100" required minlength="2" class="m" id="m5" placeholder="Enter Your Mark"/></td>
                </tr>
                <tr id="r_6" class="test">
                    <td>06</td><td id="s_6"></td><td><input type="number" min="35" max="100" required minlength="2" class="m" id="m6" placeholder="Enter Your Mark"/></td>
                </tr>
                <tr id="tot" class="test">
                    <td colspan="3"><input type="text" name="" id=""></td>
                </tr>
                <tr id="btn" class="btns">
                    <td><input type="reset" class="w-100" value="Clear" name="" id="" onclick="clr()"></td>
                    <td><input type="submit" class="w-100" value="Submit" name="" id="" onclick=""></td>
                    <td><input type="button" class="w-100" value="Calculate" name="" id="" onclick="calc()"></td>
                </tr>
            </table>
            
                
           
    </div>
    <br/>
        <div class="output d-none" id="output">
            <label for="">Total marks : <span id="tot_span"></span></label> <label for=""> Percentage : <input id="per_span" style="border: none; width: 50px;" name="per_span" value="0" />%</label>
        </div>
    </div>
        <div class="text-center">
            <?php if (isset($_GET['error'])) { 
                $error = $_GET["error"];
                $temp = $_SESSION['temp'];
                if($temp == 1)
                {
                    echo  '<p class="error text-danger font-weight-bold"> '.$error.' :(</p>';
                    $_SESSION['temp'] = 2;

                }
             } ?>
           </div>
    </form>
    <?php include 'footer.php';?>
    </body>
<script>

        const g_a = ['Tamil','English','Maths', 'Physics', 'Chemistry', 'Biology'];
        const g_b = ['Tamil','English','Maths', 'Physics', 'Chemistry', 'Computer Science'];
        const g_c = ['Tamil','English','Business Maths', 'Economics', 'Accounts', 'Computer Application'];

        const tr_id = ['r_1', 'r_2', 'r_3', 'r_4', 'r_5', 'r_6'];
        const s_id = ['s_1', 's_2', 's_3', 's_4', 's_5', 's_6'];

    function onloadFunction()
    {
        var type_ = document.getElementById('gsl').value;

        
        if(type_ == -1)
        {
            document.getElementById('dummy').style = 'display: table-row !important';
            console.log(type_);
        }
        if(type_ == 'group-a')
        {
            // document.getElementById(tr_id[i]).style = 'display: block !important';
            

            console.log(type_);
            for (let i = 0; i < g_a.length; i++) {
                
                document.getElementById(s_id[i]).innerHTML = g_a[i];
                document.getElementById(tr_id[i]).style = 'display:  table-row !important';
                console.log(g_a[i])
                
            }
            document.getElementById('dummy').style = 'display: none !important';

        }
        if(type_ == 'group-b')
        {
            console.log(type_);
            for (let i = 0; i < g_b.length; i++) {
                
                document.getElementById(s_id[i]).innerHTML = g_b[i];
                document.getElementById(tr_id[i]).style = 'display:  table-row !important';
                console.log(g_b[i])
                
            }
            document.getElementById('dummy').style = 'display: none !important';
        }
        if(type_ == 'group-c')
        {
            console.log(type_);
            for (let i = 0; i < g_c.length; i++) {
                
                document.getElementById(tr_id[i]).style = 'display:  table-row !important';
                document.getElementById(s_id[i]).innerHTML = g_c[i];
                console.log(i)
                
            }
            document.getElementById('dummy').style = 'display: none !important';
        }
        localStorage.setItem('forsubmit', -1);

    }
    function selectedGroup(event)
    {

        document.getElementById('tot_span').innerHTML = '---';
        document.getElementById('per_span').value = '---';
        // document.getElementById('output').style = 'display: flex !important';

        var type_ = event.target.value;

        

        var tr_id = ['r_1', 'r_2', 'r_3', 'r_4', 'r_5', 'r_6'];
        var s_id = ['s_1', 's_2', 's_3', 's_4', 's_5', 's_6'];
        for (let i = 0; i < tr_id.length; i++) {
                
                document.getElementById(tr_id[i]).style = 'display:  none';
                let a = 'm'+(i+1)
                document.getElementById(a).value = '';
                
            }
        if(type_ == -1)
        {
            document.getElementById('dummy').style = 'display: table-row !important';
            console.log(type_);
        }
        if(type_ == 'group-a')
        {
            // document.getElementById(tr_id[i]).style = 'display: block !important';
            

            console.log(type_);
            for (let i = 0; i < g_a.length; i++) {
                
                document.getElementById(s_id[i]).innerHTML = g_a[i];
                document.getElementById(tr_id[i]).style = 'display:  table-row !important';
                console.log(g_a[i])
                
            }
            document.getElementById('dummy').style = 'display: none !important';

        }
        if(type_ == 'group-b')
        {
            console.log(type_);
            for (let i = 0; i < g_b.length; i++) {
                
                document.getElementById(s_id[i]).innerHTML = g_b[i];
                document.getElementById(tr_id[i]).style = 'display:  table-row !important';
                console.log(g_b[i])
                
            }
            document.getElementById('dummy').style = 'display: none !important';
        }
        if(type_ == 'group-c')
        {
            console.log(type_);
            for (let i = 0; i < g_c.length; i++) {
                
                document.getElementById(tr_id[i]).style = 'display:  table-row !important';
                document.getElementById(s_id[i]).innerHTML = g_c[i];
                console.log(i)
                
            }
            document.getElementById('dummy').style = 'display: none !important';
        }
        localStorage.setItem('forsubmit', -1);

    }







    function calc()
    {
        localStorage.setItem('forsubmit', -1);

        console.log('calc')
        var selectValue = document.getElementById('gsl').value;
        if(selectValue == -1)
        {
            alert('Select the group !!!');
        }
        if(selectValue == 'group-a')
        {
            var checkValue = true
            for (let i = 0; i < g_a.length; i++) {
                let a = 'm'+(i+1)
                if(document.getElementById(a).value)
                {
                    checkValue = true;
                    continue;
                }
                else
                {
                    checkValue = false;
                    break;
                }
                
            }


            if(checkValue == true)
            {
                let tot = 0;
                for (let i = 0; i < g_a.length; i++) {
                    let a = 'm'+(i+1)
                    tot = tot + parseInt(document.getElementById(a).value)
                    
                }
                console.log(tot)
                document.getElementById('tot_span').innerHTML = tot;
                document.getElementById('per_span').value = Math.round(tot/(g_a.length));
                document.getElementById('per_span').value = Math.round(tot/(g_a.length));
                document.getElementById('output').style = 'display: flex !important';
                localStorage.setItem('forsubmit', 1);
            }
            else
            {
                alert('Enter The Marks');
                localStorage.setItem('forsubmit', -1);
            }
        }
        if(selectValue == 'group-b')
        {
            var checkValue = true
            for (let i = 0; i < g_b.length; i++) {
                let a = 'm'+(i+1)
                if(document.getElementById(a).value)
                {
                    checkValue = true;
                    continue;
                }
                else
                {
                    checkValue = false;
                    break;
                }
                
            }


            if(checkValue == true)
            {
                let tot = 0;
                for (let i = 0; i < g_b.length; i++) {
                    let a = 'm'+(i+1)
                    tot = tot + parseInt(document.getElementById(a).value)
                    
                }
                console.log(tot)
                document.getElementById('tot_span').innerHTML = tot;
                document.getElementById('per_span').value = Math.round(tot/(g_b.length));
                document.getElementById('per_span').value = Math.round(tot/(g_b.length));
                document.getElementById('output').style = 'display: flex !important';
                localStorage.setItem('forsubmit', 1);
            }
            else
            {
                alert('Enter The Marks');
                localStorage.setItem('forsubmit', -1);
            }
        }
        if(selectValue == 'group-c')
        {
            var checkValue = true
            for (let i = 0; i < g_c.length; i++) {
                let a = 'm'+(i+1)
                if(document.getElementById(a).value)
                {
                    checkValue = true;
                    continue;
                }
                else
                {
                    checkValue = false;
                    break;
                }
                
            }


            if(checkValue == true)
            {
                let tot = 0;
                for (let i = 0; i < g_c.length; i++) {
                    let a = 'm'+(i+1)
                    tot = tot + parseInt(document.getElementById(a).value)
                    
                }
                console.log(tot)
                document.getElementById('tot_span').innerHTML = tot;
                document.getElementById('per_span').value = Math.round(tot/(g_c.length));
                document.getElementById('per_span').value = Math.round(tot/(g_c.length));
                document.getElementById('output').style = 'display: flex !important';
                localStorage.setItem('forsubmit', 1);
            }
            else
            {
                alert('Enter The Marks');
                localStorage.setItem('forsubmit', -1);
            }
        }
    }
    function submit()
    {
        var forsub = localStorage.getItem('forsubmit')
        var per_span = localStorage.getItem('per_span')
        console.log(forsub)
        if(forsub == 1)
        {
            // window.location = 'contact.php';
            var tot_per = document.getElementById('per_span').value;
            localStorage.setItem('tot_per', tot_per);
            alert('Success - Your Cutoff Mark is '+tot_per);
            window.location = 'selecting clg.php'

        }
        if(forsub == -1)
        {
            console.log(per_span.value)
            alert('Complete Your Calculation');
            event.preventDefault();
            return false;
        }
        console.log('submit')
    }
    function clr()
    {

        localStorage.setItem('forsubmit', -1);
        document.getElementById('tot_span').innerHTML = '---';
        document.getElementById('per_span').value = '---';
        console.log('clr')
        for (let i = 0; i < tr_id.length; i++) {
                
            // document.getElementById(tr_id[i]).style = 'display:  none';
            let a = 'm'+(i+1)
            document.getElementById(a).value = '';
            
        }
    }
</script>
</html>