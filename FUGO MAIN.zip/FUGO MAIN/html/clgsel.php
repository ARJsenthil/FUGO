<html>
    <head><link rel="stylesheet" href="../css/style.css">
<link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css">
<style>
    .img a:hover .apply-now
    {
        display: block !important;
    }
    .img a:hover img
    {
        transition: all .3s ease-in-out;
        transform: scale(1.2);
    }
    .apply-now
    {
        background-color: rgb( 0, 0, 0, .3);
        z-index: 1;
        top: 0 !;
        h1
        {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: x-large;
        }
    }
</style></head>
<body><div class="boxes row">
<?php
    include '../php/db_conn.php';

    // Select All  Colleges From Table
    function allClg($conn)
    {
        $select = 'select * from clgdet';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div overflow-hidden">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 200).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All Grade B & C Colleges
    function bGradesStdAllClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "b" or clggrade = "c"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select All C Grade Colleges
    function allCGradeClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "c"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select Only A Grade Colleges
    function onlyAGradeClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "a"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select Only B Grade Colleges 
    function onlyBGradeClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "b"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select Only C Grade Colleges 
    function onlyCGradeClg($conn)
    {
        $select = 'select * from clgdet where clggrade = "C"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }
    }

    // Select All  Medical Colleges
    function allMedicalClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Arts Colleges
    function allArtsClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Engineering Colleges
    function allEngineeringClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Diploma Colleges
    function allDiplomaClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "diploma"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

   
    // Select All B Grade  Medical Colleges
    function allBGradeMedicalClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and ( clggrade = "b" or clggrade = "c")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All C Grade  Medical Colleges
    function allCGradeMedicalClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "medical" and clggrade = "c"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All B and C Grde  Arts Colleges
    function allBGradeArtsClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and ( clggrade = "b" or clggrade = "c" )';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All C Grade Arts Colleges
    function allCGradeArtsClg($conn)
    {
        $select = 'select * from clgdet where clgfield = "arts" and clggrade = "c"';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Engineering Colleges
    function allEngineeringClgForBGradeStudents($conn)
    {
        $select = 'select * from clgdet where clgfield = "engineering" and ( clggrade = "b" or clggrade = "c")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    // Select All  Diploma Colleges
    function allDiplomaClgForBGradeStudents($conn)
    {
        $select = 'select * from clgdet where clgfield = "diploma" and ( clggrade = "b" or clggrade = "c")';
        $selectQuery = $conn->query($select);
        while($row = mysqli_fetch_array($selectQuery))
        {
            echo '<div class="box col-4">
            <div class="clg-cont-main-div">
                <div class="img position-relative">
                    <a href="clgadminsion.php?clgid='.$row['clgid'].'" id="clg_a_1">
                        <img id="clg_img_1" src="'.$row["clgimgsrc"].'" class="slide-1" alt="">
                        <div class="w-100 h-100 d-none position-absolute apply-now">
                            <h1>Apply Now</h1>
                        </div>     
                    </a>
                </div>
                <div class="clg-cont-div">
                    <h3 class="clg-1" id="clg_h3_1">'.$row["clgname"].'</h3>
                    <p class="px-1 m-0" id="clg_p_1">'.substr($row["clgdet"], 0, 180).'</p>
                    <a href="https://'.$row['clgwebsite'].'" target="_blank">See More..</a>
                </div>
            </div>
        </div>';
        }   
    }

    allClg($conn);
?></div></body></html>