<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/aboutCss.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
</head>
<body>
    <?php include 'header.php';?>
    <div class="m-auto" style="width: 95%;">
    <section class="block">
        <h3 class="about-h3">About FUGO!</h3>
        <p class="about-p">Welcome to Fugo!,your one-stop solution for navigating the complex world of college admissions.our mission is to simplify the application process for students and streamline the admission process for college</p>
    </section>
    <section class="block">
        <h3 class="about-h3">Our Journey</h3>
        <p class="about-p">Fugo-online was born from a collective desire to democratize access to higher education. Our founding team, driven by a passion for education and a commitment to innovation, has been at the forefront of developing a platform that simplifies and streamlines the admission process.</p>
    </section>
    <section class="block">
        <h3 class="about-h3">Our Services</h3>
        <p class="about-p">We offer a comprehensive suite of services designed to make the college admission process smoother and more transparent. From application assistance to personalized college recommendations, our platform is your one-stop solution for a successful admission journey.</p>
    </section>
    <section class="team">
        <h3 class="team-1">Our Team</h3>
        <p class="about-p">Our team is a dynamic group of professionals who are passionate about education and technology. We bring a blend of expertise in full-stack developement, ensuring that our platform is both user-friendly and informative.</li>
       <div class="team-mem">
        <div class="mem">
            <div class="img">
            <div class=".img-cont">
                                <img src="../media\images\APJAbdulKalam.webp" alt="abinesh" class="img-1">
            </div>
            <h4>ABINESH</h4>
                <section class="">
                <span><i class="i fa-brands fa-instagram"></i></span><span><i class="i fa-brands fa-facebook"></i></span><span><i class="i   fa-brands fa-x-twitter"></i></span><span><i class="i fa-solid fa-envelope"></i></span>
                </section>
                <p class="about-p">Lorem ipsum, dolor sit amet consectetu tena djehuhej ndwewe redtree terfrtrytht</p>
            </div> 
        </div>
        <div class="mem">
            <div class="img">
            <div class=".img-cont">
                                <img src="../media\images\APJAbdulKalam.webp" alt="arjun" class="img-1">
            </div>
            <h4>ARJUN</h4>
                <section class="">
                    <span><i class="i fa-brands fa-instagram"></i></span><span><i class="i fa-brands fa-facebook"></i></span><span><i class="i   fa-brands fa-x-twitter"></i></span><span><i class="i fa-solid fa-envelope"></i></span>
                    </section>
                <p class="about-p">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, atque.</p>
            </div> 
        </div>
        <div class="mem">
            <div class="img">
            <div class=".img-cont">
                                <img src="../media\images\APJAbdulKalam.webp" alt="hari" class="img-1">
            </div>
            <h4>HARI HARAN</h4>
                <section class="">
                    <span><i class="i fa-brands fa-instagram"></i></span><span><i class="i fa-brands fa-facebook"></i></span><span><i class="i   fa-brands fa-x-twitter"></i></span><span><i class="i fa-solid fa-envelope"></i></span>
                    </section>
                <p class="about-p">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt modi</p>
            </div> 
        </div>
       </div>
    </section>
    <section class="block">
        <h3 class="about-h3">Join Us</h3>
        <p class="about-p">As we continue to grow and innovate, we're always looking for ways to make the admission process even better. If you're passionate about education and technology, we invite you to join us on this exciting journey.To join with us <a href="log.php" >click here</a></p>
    </section>
    </div>
    <?php include 'footer.php';?>
</body>
<script>
  const clgMenu = document.getElementById('about');
  clgMenu.classList.add('glow-btn');
</script>
</html>