<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/log.css" />
    <link rel="stylesheet" href="../css/style.css" />
    <link rel="stylesheet" href="../bootstrap/assests/css/bootstrap.min.css" />
    <script src="../js/log.js"></script>
    <style>
        footer
        {
            margin-top: 800px;
        }
    </style>
</head>
<body onload="onclickStudent()">
<?php
      if(isset($_SESSION['regSuccess']))
      {
        if($_SESSION['regSuccess'] == 'success')
        {
          echo '
          <div class=" text-center px-4 py-3 rounded m-auto clearfix position-absolute" id="success" style="z-index: 1; left: 50%; top: 30px; transform: translate(-50%, 0); background-color: rgb(60, 255, 100); width:300px;">
          <h6 class="float-left mt-1 text-white" style="font-size: 17px;">Registered Successfully</h6>
          <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" style="cursor: pointer;" onclick="successAlert()" class="text-white float-right bi bi-x" viewBox="0 0 16 16">
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
          </svg>
        </div>';
      $_SESSION['regSuccess'] = 'good';
      }}
      ?>
    <div class="main row m-auto">
        <div class="left-cont col-12 col-lg-5">
            <img src="../media/images/log_img.webp" alt="book"/>
            <h1>Welcome To <b>FUGO!</b></h1>

        </div>
        <div class="right-cont col-12 col-lg-7">
            <div class="top-cont">
                <a class="obj rounded" href="#" id="student" onclick="onclickStudent()">Students</a>
                <a class="obj rounded"href="#" id="admin" onclick="onclickAdmin()">Admin</a>
            </div>
            <form id="form" action="../php/log.php" method="POST">
                <div class="log-logo-box">
                <h1>Log In</h1>
                </div>
            
            <div class="user-div">
                <input type="text" name="u_name" placeholder="Username or Mail Id" class="w-100 rounded shadow-sm" id="u_name" minlength="6" maxlength="" required/>
            </div>

            <div class="pass-div">
                <input type="password" name="pass" placeholder="password" class="w-100 rounded shadow-sm" id="pass" minlength="6" maxlength="10" required/> 
                <i class="fa-solid fa-eye open-eye" id="open-eye" onclick="pass()"></i> <i style="display:none" class= "fa-solid fa-eye-slash close-eye" id="close-eye" onclick="pass()"></i>
            </div>

            <div class="forget-pass">
                <a href="#" id="forgotPass">Forget Password?</a>
            </div>

           <div class="continue-btn">
            <!-- <a  class="" href="#">Continue</a> -->
            <input type="submit" class="d-inline-block w-100 text-center py-2 rounded" value="Continue">
           </div>

           <div class="register-btn">
            <a  class="d-inline-block w-100 text-center" href="register.php" id="register">Register</a>
           </div>

           
           <div class="text-center">
            <?php if (isset($_GET['error'])) { ?>

                <p class="error text-danger font-weight-bold"><?php echo $_GET['error']; ?> :(</p>
    
            <?php } ?>
           </div>
            </form>

        </div>
    </div>
    <footer>
        <section class="foot">
          <div class="fst">
              <img src="" alt="logo"/>
              <h3>FUGO!</h3>
          </div>
          <div class="snd">
              <p class="bold">CONTACT:</p>
              <p class="norm"><span><i class="fa-solid fa-phone"></i></span> +91 91 50 602 650</p>
              <p class="norm"><span><i class="fa-solid fa-envelope"></i></span> abineshdio23@gmail.com</p>
              <p class="bold">FOR ADMISSION:</p>
              <p class="norm"><span><i class="fa-solid fa-phone"></i></span> +91 87 57 456 897</p>
              <p class="norm"><span><i class="fa-solid fa-envelope"></i></span> admission@gmail.com</p>
          </div>
          <div class="trd">
              <p class="bold">COMMON QUESTIONS:</p>
              <a href="#"><p class="norm">Popular colleges</p></a>
              <a href="#"><p class="norm">Locations</p></a>
              <a href="#"><p class="norm">Engineering colleges</p></a>
              <a href="#"><p class="norm">Arts and science colleges</p></a> 
              <a href="#"><p class="norm">Medical colleges</p></a>   
           </div>
          <div class="fth">
              <p class="bold">QUICK LINKS:</p>
              <a href="../index.php" target=""><p class="norm">Home</p></a>
              <a href="./selecting clg.php" target=""><p class="norm">Colleges</p></a>
              <a href="#" target=""><p class="norm">About us</p></a>
              <a href="./contact.php" target=""><p class="norm">Contacts</p></a>
              <a href="./log.php" target=""><p class="norm">Profile</p></a>
          <div class="ft-icons"></div>
              <a href="#"><span><i class="icons fa-brands fa-instagram"></i></span></a> 
              <a href="#"><span><i class="icons fa-brands fa-square-x-twitter"></i></span></a>
              <a href="#"><span><i class="icons fa-brands fa-facebook"></i></span></a>
              <a href="#"><span><i class="icons fa-brands fa-whatsapp"></i></span></a>
              <a href="#"><span><i class="icons fa-solid fa-envelope"></i></span></a>
          </div>
          </div>
      </section>
      <section class="extra">
          <p class="ext"><span><i class="fa-solid fa-copyright"></i></span> Copyrights FUGO! portal 2024. All rights reserved by the developers.</p>
      </section>
      </footer>
    
</body>
<script>
    const register = document.getElementById('register')
    const forgotPass = document.getElementById('forgotPass')
    const student = document.getElementById('student')
    const admin = document.getElementById('admin')
    const form = document.getElementById('form')
    var userType = 'student';
    function onclickAdmin()
    {
        userType = 'admin';
        // register.style = 'display: none !important;';
        // forgotPass.style = 'display: none !important';
        admin.classList.add('userType');
        student.classList.remove('userType');
        form.action = '../php/log.php?userType=admin'
    }
    function onclickStudent()
    {
        userType = 'student';
        // register.style = 'display: inline-block !important;';
        // forgotPass.style = 'display: inline-block !important;';
        student.classList.add('userType');        
        admin.classList.remove('userType');        
        form.action = '../php/log.php?userType=student'
    }
  function successAlert(){document.getElementById('success').style = "display: none;"}
</script>
</html>