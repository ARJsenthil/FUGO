
// Home CLG
const medi_clg = {

    medi : [
    // Source
    ['./media/images/medical/85-100/Annamalai University.jpg', './media/images/medical/85-100/Bhaarath Medical College and Hospital.jpeg', './media/images/medical/85-100/Chettinad Academy of Research and Education.jpg', './media/images/medical/85-100/christian medical clg-vellore.webp'],

    // CLG NAME
    ['Annamalai University', 'Bhaarath Medical College and Hospital', 'Chettinad Academy of Research and Education', 'Christian Medical College Vellore'],

    // ABOUT CLG
    
    ['The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.', 'The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.', 'The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.', 'The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.']
    ],
    engi : [
    // Source
    ['./media/images/engineering/85-100/Amrita Vishwa Vidyapeetham.jpg', './media/images/engineering/85-100/Anna University.jpg', './media/images/engineering/85-100/B.S. Abdur Rahman Crescent Institute of Science & Technology.jpg', './media/images/engineering/85-100/coimbatore_institute_of_technology_cover.jpg'],

    // CLG NAME
    ['Amrita Vishwa Vidyapeetham', 'Anna University', 'B.S. Abdur Rahman Crescent Institute of Science & Technology', 'Coimbatore Institute Of Technology Cover'],

    // ABOUT CLG
    
    ['The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.', 'The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.', 'The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.', 'The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.']
    ],
    arts : [
    // Source
    ["./media/images/arts/85-100/St. Joseph's College-cuddalore.jpg", './media/images/arts/85-100/Loyola College.jpeg', './media/images/arts/85-100/PSG College of Arts and Science.jpg', './media/images/arts/85-100/madras-christian-college-chennai.jpg'],
    
    // CLG NAME
    ["St. Joseph's College Cuddalore", 'Loyola College', 'PSG College of Arts and Science', 'Madras Christian College Chennai'],

    // ABOUT CLG    
    ["St. Joseph's College of Arts & Science, is a general degree college located in Cuddalore, Tamil Nadu. It was established in the year 1991.", 'Loyola College is a private Catholic higher education institution run by the Society of Jesus in Chennai, Tamil Nadu, India.', 'PSG College of Technology (often abbreviated as PSG Tech) is an autonomous, government aided, private engineering college in Coimbatore, India.', "Madras Christian College (MCC) is a liberal arts and sciences college in Chennai, India. Founded in 1837, MCC is one of Asia's oldest extant colleges"]
    ],
    diplo : [
    // Source
    ['./media/images/medical/85-100/Annamalai University.jpg', './media/images/medical/85-100/Bhaarath Medical College and Hospital.jpeg', './media/images/medical/85-100/Chettinad Academy of Research and Education.jpg', './media/images/medical/85-100/christian medical clg-vellore.webp'],

    // CLG NAME
    ['Annamalai University', 'Bhaarath Medical College and Hospital', 'Chettinad Academy of Research and Education', 'Christian medical College Vellore'],

    // ABOUT CLG
    ['The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.', 'The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.', 'The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.', 'The Annamalai University (informally titled as AU) is a public state university[3] in Chidambaram, Tamil Nadu, India.']
    ]
}

const medical_Home = document.getElementById('medical_Home');
const eng_Home = document.getElementById('eng_Home');
const arts_Home = document.getElementById('arts_Home');
const dip_Home = document.getElementById('dip_Home');

function indexLoad()
{
    medical_Home.style = 'color: rgba(9, 190, 250, 0.9); border: 3px solid rgba(9, 190, 250, 0.9); background-color: rgba(9, 190, 250, 0.1);';
    eng_Home.style = 'color: black;';
    arts_Home.style = 'color: black;';
    dip_Home.style = 'color: black;';
    
    
    
    for (let i = 0; i < 4 ; i++) {
        
    
        document.getElementById('clg_img_'+(i+1)).src = medi_clg.medi[0][i];
        document.getElementById('clg_h3_'+(i+1)).innerHTML = medi_clg.medi[1][i];
        document.getElementById('clg_p_'+(i+1)).innerHTML =  medi_clg.medi[2][i];  
    }
}

function medicalHome()
{
    medical_Home.style = 'color: rgba(9, 190, 250, 0.9); border: 3px solid rgba(9, 190, 250, 0.9); background-color: rgba(9, 190, 250, 0.1);';
    eng_Home.style = 'color: black;';
    arts_Home.style = 'color: black;';
    dip_Home.style = 'color: black;';
    
    
    
    for (let i = 0; i < 4 ; i++) {
        
    
        document.getElementById('clg_img_'+(i+1)).src = medi_clg.medi[0][i];
        document.getElementById('clg_h3_'+(i+1)).innerHTML = medi_clg.medi[1][i];
        document.getElementById('clg_p_'+(i+1)).innerHTML =  medi_clg.medi[2][i];  
    }   

}
function engHome()
{
    medical_Home.style = 'color: black; background-color: white;';
    eng_Home.style = 'color: rgba(9, 190, 250, 0.9); border: 3px solid rgba(9, 190, 250, 0.9); background-color: rgba(9, 190, 250, 0.1);';
    arts_Home.style = 'color: black;';
    dip_Home.style = 'color: black;';

    for (let i = 0; i < 4 ; i++) {
        
    
        document.getElementById('clg_img_'+(i+1)).src = medi_clg.engi[0][i];
        document.getElementById('clg_h3_'+(i+1)).innerHTML = medi_clg.engi[1][i];
        document.getElementById('clg_p_'+(i+1)).innerHTML =  medi_clg.engi[2][i];  
    }    

}
function artsHome()
{
    medical_Home.style = 'color: black; background-color: white;';
    eng_Home.style = 'color: black;';
    arts_Home.style = 'color: rgba(9, 190, 250, 0.9); border: 3px solid rgba(9, 190, 250, 0.9); background-color: rgba(9, 190, 250, 0.1);';
    dip_Home.style = 'color: black;';

    for (let i = 0; i < 4 ; i++) {
        
    
        document.getElementById('clg_img_'+(i+1)).src = medi_clg.arts[0][i];
        document.getElementById('clg_h3_'+(i+1)).innerHTML = medi_clg.arts[1][i];
        document.getElementById('clg_p_'+(i+1)).innerHTML =  medi_clg.arts[2][i];  
    }    

}
function dipHome()
{
    medical_Home.style = 'color: black; background-color: white;';
    eng_Home.style = 'color: black;';
    arts_Home.style = 'color: black;';
    dip_Home.style = 'color: rgba(9, 190, 250, 0.9); border: 3px solid rgba(9, 190, 250, 0.9); background-color: rgba(9, 190, 250, 0.1);';

    for (let i = 0; i < 4 ; i++) {
        
    
        document.getElementById('clg_img_'+(i+1)).src = medi_clg.diplo[0][i];
        document.getElementById('clg_h3_'+(i+1)).innerHTML = medi_clg.diplo[1][i];
        document.getElementById('clg_p_'+(i+1)).innerHTML =  medi_clg.diplo[2][i];  
    }    

}