<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FUGO!</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./bootstrap/assests/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;1,700&family=Nunito+Sans:ital,opsz,wght@0,6..12,200..1000;1,6..12,200..1000&family=Source+Code+Pro:wght@600&family=Titillium+Web:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700&family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Exo+2:ital,wght@0,100..900;1,100..900&family=Lato:ital,wght@0,300;0,400;1,700&family=Nunito+Sans:ital,opsz,wght@0,6..12,200..1000;1,6..12,200..1000&family=Source+Code+Pro:wght@600&family=Titillium+Web:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700&family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
      
</head>
<body onload="indexLoad()">
<?php
    session_start();
    if(isset($_SESSION['userType']))
    {
    echo '<input id="userType" style="display: none; type="text" value='.$_SESSION['userType'].' />';
    echo '<input id="userName" style="display: none; type="text" value='.$_SESSION['uname'].' />';
    }
?>

    <header class="header ">
        
        <nav class="navbar navbar-expand-lg navbar-light c-w m-auto">
            <a class="navbar-brand h-1" href="#">FUGO!</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
          
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav m-auto">
                <li class="menu glow">
                  <a class="nav-link" href="./index.php">Home</a>
                </li>
                <li class="  menu">
                  <a class="nav-link" href="#colleges">Colleges</a>
                </li>
                <li class="  menu">
                    <a class="nav-link" href="./html/about.php">About us</a>
                  </li>
                  <?php 
                  if(isset($_SESSION['userType']))
                  {
                    if($_SESSION['userType'] != 'admin')
                    {
                      echo '<li class="  menu" id="contact">
                      <a class="nav-link" href="./html/contact.php">Contacts</a>
                    </li>';
                    }
                  }
                  else{
                    echo '<li class="  menu" id="contact">
                      <a class="nav-link" href="./html/contact.php">Contacts</a>
                    </li>';
                  }
                  ?>
                  <?php 
                  if(isset($_SESSION['userType']))
                  {
                    if($_SESSION['userType'] == 'admin')
                    {
                      echo '<li class="  menu" id="admin">
                      <a class="nav-link" href="./html/admin.php?menu=dBoard">Admin Panel</a>
                    </li>';
                    }
                  }
                  ?>
                  <li class="  menu">
                    <a class="nav-link" href="./html/log.php" id="profile">Login</a>
                  </li>
              </ul>
              <div class="box-1">
                  <a href="./html/log.php" id="forYou" class="button-1">For You</a>
              </div>
              
            </div>
          </nav>
    </header>

    <main>
      <?php
      if(isset($_SESSION['indexSuccess']))
      {
        if($_SESSION['indexSuccess'] == 'success')
        {
          echo '
        <div class=" text-center px-4 py-3 rounded m-auto clearfix position-absolute" id="success" style="z-index: 1; left: 50%; top: 100px; transform: translate(-50%, 0); background-color: rgb(60, 255, 100); width:300px;">
        <h6 class="float-left mt-1 text-white" style="font-size: 17px;">Welcome To FUGO</h6>
        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" style="cursor: pointer;" onclick="successAlert()" class="text-white float-right bi bi-x" viewBox="0 0 16 16">
        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg>
      </div>';
      $_SESSION['indexSuccess'] = 'good';
      }}
      else if(isset($_SESSION['logOutSuccess']))
      {
        if($_SESSION['logOutSuccess'] == 'success')
        {
          echo '
        <div class=" text-center px-4 py-3 rounded m-auto clearfix position-absolute bg-alert" id="success" style="z-index: 1; left: 50%; top: 100px; transform: translate(-50%, 0); background-color: rgb(255, 0, 0); width:300px;">
        <h6 class="float-left mt-1 text-white" style="font-size: 17px;">Logged Out</h6>
        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" style="cursor: pointer;" onclick="successAlert()" class="text-white float-right bi bi-x" viewBox="0 0 16 16">
        <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg>
      </div>';
      $_SESSION['logOutSuccess'] = 'good';
      }}
      ?>
      <section class="slider" id="home">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
              <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
              <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
              <li data-target="#carouselExampleCaptions" data-slide-to="4"></li>
            </ol>
            <div class="carousel-inner">
              
                <div class="home carousel-item active" id="home">
                    <div class="container">
                      <div class="row">
                        <div class="col-12 col-lg-6 home-content">
                          <h1 class="text-white home-h1">
                            Better College For Better Future!
                          </h1>
                          <p class="text-white home-p">
                           We are the group to <b>Enlighten</b> your Future!
                          </p>
                          <div class="home-watch-box d-flex align-items-center">
                                <a href="./html/log.php" class="home-get-st text-white text-decoration-none">Get Started</a>
                          </div>
                        </div>
                        <div class="col-12 col-lg-6 home-img-box">
                          <img src="./media/images/hero-img.png" class="home-img d-flex align-items-center jusify-content-center m-0 w-100" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img src="./media/images/medical/slider-med.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Medical</h5>
                      <h6>All doctors treat, But a best doctor lets nature heal. </h6>
                    </div>
                  </div>
              <div class="carousel-item">
                <img src="./media/images/engineering/slider-eng.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                  <h5>Engineering</h5>
                  <p class="text-white">Engineering is the art of solving problems with numbers and equations, turning imagination into reality.</p>
                </div>
              </div>
              <div class="carousel-item">
                <img src="./media/images/arts/slider-arts.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                  <h5>Arts and Science</h5>
                  <p class="text-white">Arts and science intertwine, where creativity meets innovation, and imagination fuels discovery.</p>
                </div>
              </div>
              <div class="carousel-item">
                <img src="./media/images/diploma/slider.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                  <h5>Polytechnic</h5>
                  <p class="text-white">"A diploma is a testament to hard work, dedication, and the pursuit of knowledge</p>
                </div>
              </div>
            </div>
            <button class="carousel-control-prev" type="button" data-target="#carouselExampleCaptions" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-target="#carouselExampleCaptions" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </button>
          </div>
    </section>
        <section class="cont">
          <div class="minilogo">
              <a href="https://www.annauniv.edu/"><img class="ima" src="./media/images/top clg/anna university.png" alt="anna univ"></a>
              <p>ANNA UNIVERSITY</p>
          </div>
          <div class="minilogo">
              <a href="https://annamalaiuniversity.ac.in/index.php"><img class="ima" src="./media/images/top clg/annamalai.png" alt="annamalai univ"></a>
              <p>ANNAMALAI UNIVERSITY</p>
          </div>
          <div class="minilogo">
              <a href="https://hindustanuniv.ac.in/"><img class="ima" src="./media/images/top clg/hindhustan.jpg" alt="hindhustan"></a>
              <p>HINDUSTAN UNIVERSITY</p>
          </div>
          <div class="minilogo">
              <a href="https://www.iitm.ac.in/"><img class="ima" src="./media/images/top clg/IIT Madras.png" alt="IIT madras"></a>
              <p>IIT MADRAS</p>
          </div>
          <div class="minilogo">
              <a href="https://www.tnmgrmu.ac.in/"><img class="ima" src="./media/images/top clg/Madras medical clg.png" alt="madras med"></a>
              <p>MADRAS MEDICAL COLLEGE</p>
          </div>
          <div class="minilogo">
              <a href="https://www.srmist.edu.in/"><img class="ima" src="./media/images/top clg/srm.png" alt="srm"></a>
              <p>SRM UNIVERSITY</p>
          </div>
          <div class="minilogo">
              <a href="https://vistas.ac.in/"><img class="ima" src="./media/images/top clg/Vels uni.png" alt="vels univ"></a>
              <p>VELS UNIVERSITY</p>
          </div>
          <div class="minilogo">
              <a href="https://viteee.vit.ac.in/"><img class="ima" src="./media/images/top clg/VIT.png" alt="vit"></a>
              <p>VELLORE INSTITUTE OF TECHNOLOGY</p>
          </div>
      </section>
      <section class="why"> 
          <h3>Choose Your Carrier !   </h3>
          <div class="why-cont  justify-content-center">
              <div class="abou">
                <img src="./media/images/top clg/med.jpg" alt="medical" class="abo">
                <p class="tit">Medical</p>
                <p class="quo">You medical people will have more lives to answer for in the other world than even we generals!</p>
            </div>
            <div class="abou">
                <img src="./media/images/top clg/eng.jpg" alt="engineering" class="abo">
                <p class="tit">Engineering</p>
                <p class="quo">Engineering is the closest thing to magic that exists in the world!</p>
            </div>
            <div class="abou">
                <img src="./media/images/top clg/art.jpg" alt="arts and science" class="abo">
                <p class="tit">Arts and science</p>
                <p class="quo">Science is organized knowledge.Wisdom is organized life!</p>
            </div>
            <div class="abou">
                <img src="./media/images/top clg/poly.jpg" alt="polytechnic" class="abo">
                <p class="tit">Polytechnic</p>
                <p class="quo">Art without technic is dreaming.Technic without art is calculating!</p>
            </div>
          </div>
      </section>

      <section class="home-clg" id="colleges">
    <div class="home-clg-top" >
        <button class="course" id="medical_Home" onclick="medicalHome()">Medical</button>
        <button class="course" id="eng_Home" onclick="engHome()">Engineering</button>
        <button class="course" id="arts_Home" onclick="artsHome()">Arts and Science</button>
        <button class="course" id="dip_Home" onclick="dipHome()">Diplomo</button>
    </div>

    <div class="boxes pb-2 row">
    <div class="box col-3">
        <div class="clg-cont-main-div">
            <div class="img">
                            <a href="#" id="clg_a_1"><img id="clg_img_1" src="" class="slide-1" alt="">     </a>
            </div>
            <div class="clg-cont-div">
                <h3 class="clg-1" id="clg_h3_1"></h3>
                <p class="px-1 m-0" id="clg_p_1"></p>
            </div>
        </div>
    </div>
    <div class="box col-3">
        <div class="clg-cont-main-div">
            <div class="img">
                            <a href="#" id="clg_a_2"><img id="clg_img_2" src="" class="slide-2" alt="">      </a>
            </div>
            <div class="clg-cont-div">
                <h3 class="clg-2" id="clg_h3_2"></h3>
                <p class="px-1 m-0" id="clg_p_2"></p>
            </div>
        </div>
    </div>
    <div class="box col-3">
        <div class="clg-cont-main-div">
            <div class="img">
                            <a href="#" id="clg_a_3"><img id="clg_img_3" src="" class="slide-3" alt="">      </a>
            </div>
            <div class="clg-cont-div">
                <h3 class='clg-3' id="clg_h3_3"></h3>
                <p class="px-1 m-0" id="clg_p_3"></p>
            </div>
        </div>
    </div>
    <div class="box col-3">
        <div class="clg-cont-main-div">
            <div class="img">
                            <a href="#" id="clg_a_4"><img id="clg_img_4" src="" class="slide-4" alt="">     </a>
            </div>
            <div class="clg-cont-div">
                <h3 class="clg-4" id="clg_h3_4"></h3>
                <p class="px-1 m-0   " id="clg_p_4"></p>
            </div>
        </div>
    </div>
</div>
<div class="d-flex justify-content-center pb-5"><a href="./html/log.php" id="seeMoreClg" >See More..</a></div>
</section>
<section class="achivers">
  <div class="main-box">
    <h3 class="head-1">ACHIVERS!!</h3>
    <div class="boxes">
    <div class="box-1">
        <div class="apj">
            <img class='img-1' src="./media/images/APJAbdulKalam.webp" alt="">
        </div>
        <div class="apj dream">
            <h4 class="head-2">APJ Abdul Kalam</h4>
            <p class="p-1">Avul Pakir Jainulabdeen Abdul Kalam BR (15 October 1931 - 27 July 2015) was an Indian aerospace scientist and statesman who served as the 11th president of India from 2002 to 2007. He was born and raised in Rameswaram, Tamil Nadu and studied physics and aerospace engineering. He spent the next four decades as a scientist and science administrator, mainly at the Defence Research and Development Organisation (DRDO) and Indian Space Research Organisation (ISRO) and was intimately involved in India's civilian space programme and military missile development efforts.</p>
        </div>
    </div>
    <div class="box-2">
        <div class="sundar dream-1">
            <h4 class="head-3">Sundar Pichai</h4>
            <p class="p-2">Pichai Sundararajan (born June 10, 1972), better known as Sundar Pichai is an Indian-born American business executive. He is the chief executive officer (CEO) of Alphabet Inc. and its subsidiary Google.

                Pichai began his career as a materials engineer. Following a short stint at the management consulting firm McKinsey & Co., Pichai joined Google in 2004, where he led the product management and innovation efforts for a suite of Google's client software products, including Google Chrome and ChromeOS, as well as being largely responsible for Google Drive.</p>
        </div>
        <div class="sundar">
        <img class='img-2' src="./media/images/sundar.png" alt="">    
    </div>
    </div>
  </div>
</section>
<section class="about" id="about_us">
  <div class="about-us">
  <h1 class="title m-0">About us</h1>
  <div class="about-main-cont">
    <div class="about-img">
      <img src="./media/images/about-img.jpg" alt="aboutus" class="img">
  </div>
  <div class="about-cont">
      <p class="head m-0 p-0">Welcome to FUGO!</p>
      <p class="point m-0 p-0"><span class="side">FUGO!</span> ,your one-stop solution for navigating the complex world of college admissions. Our mission is to simplify the application process for students and streamline the admission process for colleges. </p>
      <p class="head m-0 p-0 pt-3 ">Why choose FUGO?</p>
      <p class="point m-0 p-0"><span class="side">Ease of Use:</span> Our intuitive interface makes it easy for students to apply to multiple colleges with just a few clicks.</p>
      <p class="point m-0 p-0"><span class="side">Comprehensive Information:</span> We provide detailed information about each college, including admission requirements, campus life, and financial options.</p>
  </div>
  </div>
</div>
  </section>
    </main>

    <footer>
      <section class="foot">
        <div class="fst">
            <img src="" alt="logo"/>
            <h3>FUGO!</h3>
        </div>
          <div class="snd">
              <p class="bold">CONTACT:</p>
              <p class="norm"><span><i class="fa-solid fa-phone"></i></span> +91 123 123 1234</p>
              <p class="norm"><span><i class="fa-solid fa-envelope"></i></span> fugo@gmail.com</p>
              <p class="bold">FOR ADMISSION:</p>
              <p class="norm"><span><i class="fa-solid fa-phone"></i></span> +91 123 123 1234</p>
              <p class="norm"><span><i class="fa-solid fa-envelope"></i></span> admission@gmail.com</p>
          </div>
        <div class="trd">
            <p class="bold">COMMON QUESTIONS:</p>
            <a href="#"><p class="norm">Popular colleges</p></a>
            <a href="#"><p class="norm">Locations</p></a>
            <a href="#"><p class="norm">Engineering colleges</p></a>
            <a href="#"><p class="norm">Arts and science colleges</p></a> 
            <a href="#"><p class="norm">Medical colleges</p></a>   
         </div>
        <div class="fth">
            <p class="bold">QUICK LINKS:</p>
            <a href="#" target=""><p class="norm">Home</p></a>
            <a href="#" target=""><p class="norm">Colleges</p></a>
            <a href="#" target=""><p class="norm">About us</p></a>
            <a href="#" target=""><p class="norm">Contacts</p></a>
            <a href="#" target=""><p class="norm">Profile</p></a>
        <div class="ft-icons"></div>
            <a href="#"><span><i class="icons fa-brands fa-instagram"></i></span></a> 
            <a href="#"><span><i class="icons fa-brands fa-square-x-twitter"></i></span></a>
            <a href="#"><span><i class="icons fa-brands fa-facebook"></i></span></a>
            <a href="#"><span><i class="icons fa-brands fa-whatsapp"></i></span></a>
            <a href="#"><span><i class="icons fa-solid fa-envelope"></i></span></a>
        </div>
        </div>
        
    </section>
    
    <section class="extra">
        <p class="ext"><span><i class="fa-solid fa-copyright"></i></span> Copyrights FUGO! portal 2024. All rights reserved by the developers.</p>
    </section>
    </footer>
</body>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
<script src="./js/script.js"></script>
<script>
  console.log()
  function successAlert(){document.getElementById('success').style = "display: none;"}
  const seeMoreClg = document.getElementById('seeMoreClg');
  const forYou = document.getElementById('forYou');
  const profile = document.getElementById('profile');
  const userType = document.getElementById('userType');
  const userName = document.getElementById('userName');
    if(userType.value == 'student' || userType.value == 'admin')
    {
      forYou.href = './html/for you.php';
      seeMoreClg.href = './html/selecting clg.php';
      profile.innerHTML = 'Logout'
      profile.href = './php/log out.php'
    }
    localStorage.setItem('userType', userType.value);
    localStorage.setItem('uname', userName.value);
</script>
</html>
